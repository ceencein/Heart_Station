# ตู้แบ่งปัน 3 ช่องไร้สัมผัส บน FPGA 2 บอร์ด — ชุดไฟล์สุดท้าย

ทุกไฟล์ `.vhd` / `.xdc` เขียนคอมเมนต์เป็นภาษาอังกฤษ (Vivado อ่านได้)
Part: **xc7s15ftgb196-1** (EDGE Spartan-7)

```
locker_final/
├─ board1/   ← โปรเจกต์ Vivado บอร์ด 1 (เซ็นเซอร์ท่ามือ → UART)  top = board1
├─ board2/   ← โปรเจกต์ Vivado บอร์ด 2 (ตู้: จอ + เซอร์โว + LED) top = board2
├─ sim/      ← testbench (ไม่ต้องใส่ถ้าไม่จำลอง)
├─ make_board1.tcl  ← สคริปต์สร้างโปรเจกต์บอร์ด 1 อัตโนมัติ
└─ make_board2.tcl  ← สคริปต์สร้างโปรเจกต์บอร์ด 2 อัตโนมัติ
```

แต่ละโฟลเดอร์บอร์ด **ครบในตัว** ใส่ทุกไฟล์ในโฟลเดอร์นั้นได้เลย (ไฟล์ที่ใช้ร่วมกันถูกคัดลอกไว้ทั้งสองโฟลเดอร์แล้ว)

## ระบบตั้งชื่อ

ชื่อไฟล์ = ชื่อ entity ขึ้นต้นตามกลุ่มหน้าที่

| กลุ่ม | ความหมาย |
|---|---|
| `board1`, `board2` | **top** ของแต่ละบอร์ด |
| `pkg_` | ค่าคงที่ที่สองบอร์ดต้องตรงกัน (รหัสคำสั่งบัส, สถานะ FSM) |
| `sensor_` | เซ็นเซอร์ท่ามือ PAJ7620 และ I2C |
| `bus_` | การสื่อสารระหว่างบอร์ด (UART ส่ง / รับ) |
| `ctrl_` | ตรรกะควบคุมตู้ (FSM + ข้อความ) |
| `io_` | ขับอุปกรณ์บนบอร์ด (ปุ่ม, บัซเซอร์, 7-segment, LCD, เซอร์โว) |
| `sys_` | ระบบดูแลบอร์ด (watchdog) |
| `sim_`, `tb_` | ใช้เฉพาะการจำลอง |

## โครงสร้างแบบ top-down

top ของแต่ละบอร์ดมีแค่กล่องต่อสายกัน ไม่มี logic เอง ทำให้ schematic ชั้นบนสุดใน Vivado (RTL ANALYSIS → Schematic) มีแค่ไม่กี่กล่อง แล้วกางลงไปทีละชั้นได้

```
board1 (layer 1)                         board2 (layer 1)
├─ sys_reset ──────── sys_watchdog       ├─ sys_reset ──── sys_watchdog (ปิด)
├─ io_buttons ─────── io_debounce ×4     ├─ io_buttons ─── io_debounce ×4
├─ sensor_paj7620 ─┬─ sensor_i2c         ├─ bus_link_b2 ─┬ bus_uart_rx
│                  └─ sensor_paj7620_rom │               └ bus_uart_tx
├─ bus_link_b1 ────┬─ bus_uart_tx        ├─ ctrl_fsm
│                  └─ bus_uart_rx        ├─ io_display ──┬ ctrl_text
└─ io_status ──────┬─ io_seg7            │               ├ io_lcd
                   └─ io_buzzer          │               └ io_seg7
     (layer 2)          (layer 3)        └─ io_slots ──── io_servo ×3
```

## บอร์ด 1 — `board1/` (14 ไฟล์ + XDC)

| ไฟล์ | layer | หน้าที่ |
|---|---|---|
| `board1.vhd` | 1 (top) | ต่อ 5 กล่อง |
| `sys_reset.vhd` | 2 | reset ตอนเปิดเครื่อง + ปุ่มกลาง + watchdog |
| `io_buttons.vhd` | 2 | ปุ่ม 4 ปุ่ม |
| `sensor_paj7620.vhd` | 2 | เซ็นเซอร์ท่ามือ (ไฟล์นี้มี 2 entity: ตัวควบคุม + ตารางตั้งค่า) |
| `bus_link_b1.vhd` | 2 | เลือกคำสั่ง (ท่ามือ/ปุ่ม), ส่ง-รับ UART, รอคำตอบ, สถานะลิงก์ |
| `io_status.vhd` | 2 | LED, 7-segment, บัซเซอร์ |
| `sys_watchdog.vhd` | 3 | รีเซ็ตเองเมื่อเงียบนาน (ใน sys_reset) |
| `io_debounce.vhd` | 3 | กรองปุ่ม 1 ปุ่ม (ใน io_buttons) |
| `sensor_i2c.vhd` | 3 | I2C master (ใน sensor_paj7620) |
| `bus_uart_tx.vhd` / `bus_uart_rx.vhd` | 3 | UART ส่ง / รับ (ใน bus_link_b1) |
| `io_seg7.vhd` / `io_buzzer.vhd` | 3 | 7-segment / บัซเซอร์ (ใน io_status) |
| `pkg_locker.vhd` | – | ค่าคงที่ร่วม (รหัสคำสั่ง, ไบต์ UART, สถานะ FSM) |
| `board1.xdc` | – | ขา |

## บอร์ด 2 — `board2/` (16 ไฟล์ + XDC)

| ไฟล์ | layer | หน้าที่ |
|---|---|---|
| `board2.vhd` | 1 (top) | ต่อ 6 กล่อง |
| `sys_reset.vhd` | 2 | reset ตอนเปิดเครื่อง + ปุ่มกลาง (watchdog ปิด) |
| `io_buttons.vhd` | 2 | ปุ่ม 4 ปุ่ม |
| `bus_link_b2.vhd` | 2 | รับ UART + รวมกับปุ่ม, ตอบ A/R, heartbeat |
| `ctrl_fsm.vhd` | 2 | FSM 5 สถานะ + จำช่องว่าง/มีของ (ไฟล์นี้มี `ctrl_text` ด้วย) |
| `io_display.vhd` | 2 | จอ LCD + 7-segment |
| `io_slots.vhd` | 2 | เซอร์โว 3 ตัว (ตั้งมุมเป็นองศา) + LED ช่อง |
| `sys_watchdog.vhd`, `io_debounce.vhd` | 3 | (ใน sys_reset, io_buttons) |
| `bus_uart_rx.vhd` / `bus_uart_tx.vhd` | 3 | (ใน bus_link_b2) |
| `ctrl_text` (ใน `ctrl_fsm.vhd`), `io_lcd.vhd`, `io_seg7.vhd` | 3 | (ใน io_display) |
| `io_servo.vhd` | 3 | PWM เซอร์โว (ใน io_slots) |
| `pkg_locker.vhd` | – | ไฟล์เดียวกับบอร์ด 1 |
| `board2.xdc` | – | ขา |

## วิธีที่ง่ายที่สุด: สคริปต์สร้างโปรเจกต์อัตโนมัติ

1. แตก zip ไว้ที่ path สั้น ไม่มีเว้นวรรค/ภาษาไทย/OneDrive เช่น `C:\fpga\locker_final`
2. เปิด Vivado (หน้าแรก ยังไม่ต้องเปิดโปรเจกต์) → **Tools → Run Tcl Script...** → เลือก `make_board1.tcl`
3. Vivado สร้างโปรเจกต์ `vivado_board1/` ใส่ไฟล์ครบ ตั้ง top, XDC, testbench และเปิดการสร้าง `.bin` ให้แล้ว → กด **Generate Bitstream**
4. บอร์ด 2: File → Close Project แล้วทำซ้ำด้วย `make_board2.tcl`

รันสคริปต์ซ้ำได้ (ใช้ `-force` จะสร้างโปรเจกต์ทับของเดิม)

## วิธีใส่ไฟล์ใน Vivado ด้วยมือ (ทำแยกบอร์ดละโปรเจกต์)

1. **Create Project** → RTL Project → Part `xc7s15ftgb196-1`
2. **Add Sources → Add or create design sources → Add Files** → เลือก **ทุกไฟล์ `.vhd`** ในโฟลเดอร์ `board1/` (หรือ `board2/`)
3. **Add Sources → Add or create constraints → Add Files** → `board1.xdc` (หรือ `board2.xdc`) ไฟล์เดียว
4. ใน Sources คลิกขวา `board1` (หรือ `board2`) → **Set as Top**
5. **Generate Bitstream** → Hardware Manager → Program Device

ถ้าเปิดโปรเจกต์เดิมอยู่: Remove ไฟล์เก่าทั้งหมดออกก่อน แล้วค่อย Add ชุดนี้ (ชื่อ entity เปลี่ยนแล้ว ไฟล์เก่าปนจะชนกัน)

## ค่าที่ปรับบ่อย

| ไฟล์ | generic | ค่าเริ่ม | ความหมาย |
|---|---|---|---|
| `board1.vhd` | `WDT_S` | 120 | ไม่มีคำสั่งกี่วินาที → รีเซ็ตบอร์ด 1 เอง (0 = ปิด) |
| `board1.vhd` | `POLL_MS` / `HOLD_MS` | 10 / 150 | ความเร็วอ่านเซ็นเซอร์ / พักหลังรับท่า |
| `board1.vhd` | `NEXT_BIT` … `CANCEL_BIT` | 3, 2, 6, 7 | ท่าไหนเป็นคำสั่งไหน |
| `sensor_paj7620.vhd` | `IDLE_REINIT_S` | 60 | เงียบกี่วินาที → ตั้งค่าเซ็นเซอร์ใหม่ |
| `io_buzzer.vhd` | `SHORT` / `LONG` | 200 / 500 ms | ความยาวเสียง |
| `board2.vhd` | `SERVO_LOCK_DEG` / `SERVO_UNLOCK_DEG` | 45 / 135 | มุมกลอน (องศา) |
| `board2.vhd` | `SERVO_SPEED_DPS` | 180 | ความเร็วหมุน องศา/วินาที |
| `board2.vhd` | `IDLE_S` / `DONE_MS` | 30 s / 3000 ms | หมดเวลาเลือก / เวลาแสดง THANK YOU |

## การจำลอง (`sim/`) — ไม่บังคับ

| testbench | ใส่ในโปรเจกต์ | ตรวจอะไร | ไฟล์ sim ที่ต้องใส่เพิ่ม |
|---|---|---|---|
| `tb_uart.vhd` | บอร์ดไหนก็ได้ | UART ส่ง-รับ 256 ค่า, กันสัญญาณรบกวน, stop bit ผิด | – |
| `tb_board1.vhd` | บอร์ด 1 | ท่ามือ → ส่ง UART, watchdog, ไม่มีคำตอบ | `sim_paj7620_model.vhd` |
| `tb_sensor.vhd` | บอร์ด 1 | กู้เซ็นเซอร์: ไฟดับ, SDA ค้าง, ค่าตั้งหาย | `sim_paj7620_model.vhd` |
| `tb_board2_fsm.vhd` | บอร์ด 2 | FSM 5 สถานะ + ระบบช่องว่าง/มีของ ครบทุกเส้นทาง | – |
| `tb_board2_lcd.vhd` | บอร์ด 2 | ข้อความ LCD ทุกสถานะ + timing จอ | – |
| `tb_board2_servo.vhd` | บอร์ด 2 | มุมเซอร์โว + หมุนนุ่ม | – |
| `tb_system.vhd` | (โปรเจกต์ไหนก็ได้ ที่ใส่ไฟล์ครบทั้งสองบอร์ด) | ระบบเต็มด้วยท่ามือ + UART สองทาง + สายหลุด | `sim_paj7620_model.vhd` |

Add Sources → Add or create simulation sources → คลิกขวา testbench → Set as Top → Run Behavioral Simulation → Run All → ดู `ALL TESTS PASSED` ใน Tcl Console

## ระบบจำช่องว่าง / มีของ (ใน `ctrl_fsm.vhd`)

- เปิดเครื่อง: ทุกช่อง **ว่าง**
- **ผู้ให้** เลือกได้เฉพาะช่องว่าง → หมุนตามเข็มตอน PROCESS = ใส่ของแล้ว ช่องกลายเป็น **มีของ**
- **ผู้รับ** เลือกได้เฉพาะช่องที่มีของ → หมุนตามเข็มตอน PROCESS = หยิบแล้ว ช่องกลายเป็น **ว่าง**
- ปัดซ้าย/ขวาตอนเลือกช่อง ข้ามช่องที่เลือกไม่ได้ให้เอง
- ไม่มีช่องให้เลือก: จอขึ้น `ALL SLOTS FULL` (ผู้ให้) / `NO ITEMS YET` (ผู้รับ) และหมุนตามเข็มไปต่อไม่ได้
- หมุน **ทวน**เข็มตอน PROCESS = ล็อกโดยไม่เปลี่ยนสถานะช่อง จอขึ้น `CANCELLED`
- จอตอน IDLE: ` Drop and Pick !` / `SWIPE  ITEMS:2/3`
- LED ช่อง: ติดจ้า = ปลดกลอน, กะพริบ = กำลังเลือก, **หรี่ = มีของ**, ดับ = ว่าง
- ข้อจำกัด: ไม่มีเซ็นเซอร์ในช่อง ระบบเชื่อตามที่ผู้ใช้ยืนยัน และข้อมูลหายเมื่อปิดไฟ/รีเซ็ตบอร์ด 2

## การสื่อสาร UART สองทาง (บอร์ด 1 ⇄ บอร์ด 2)

115200 baud, 8N1 (start 1 บิต, ข้อมูล 8 บิต LSB ก่อน, stop 1 บิต) ไม่มี parity

| ทิศทาง | ไบต์ | ความหมาย |
|---|---|---|
| บอร์ด 1 → 2 | `N` (0x4E) / `P` (0x50) / `C` (0x43) / `X` (0x58) | NEXT / PREV / CONFIRM / CANCEL |
| บอร์ด 2 → 1 | `A` (0x41) | รับคำสั่งแล้ว (สถานะ/บทบาท/ช่อง เปลี่ยน) |
| บอร์ด 2 → 1 | `R` (0x52) | คำสั่งไม่มีผล (เช่น ช่องเต็ม, ทำท่าตอน DONE) |
| บอร์ด 2 → 1 | `H` (0x48) | heartbeat ทุก 1 วินาที |

บอร์ด 1:
- เสียง: `A` → บี๊บ 1 ครั้ง (CONFIRM ยาว), `R` หรือไม่ตอบใน 100 ms → บี๊บ 2 จังหวะ
- LED6 = ลิงก์ปกติ (ได้ยินบอร์ด 2 ภายใน 3 s), LED7 = คำสั่งล่าสุดไม่ผ่าน
- 7-seg หลักที่ 2: `-` ปกติ, `r` ไม่ผ่าน, `E` ลิงก์ขาด

### การต่อสาย (ขาเลขเดียวกันตรง ๆ 3 เส้น)
```
บอร์ด 1 J5 pin4 (GND) ─────────── บอร์ด 2 J5 pin4 (GND)
บอร์ด 1 J5 pin5 (uart_tx, L14) ──► บอร์ด 2 J5 pin5 (uart_rx, L14)
บอร์ด 1 J5 pin6 (uart_rx, M13) ◄── บอร์ด 2 J5 pin6 (uart_tx, M13)
```
J5 pin7, pin8 ว่างแล้ว (ถอดสายเดิมออกได้)
ดีบัก: ต่อ RX ของ USB-to-UART (3.3V) เข้า pin5 หรือ pin6 + GND แล้วเปิด terminal 115200 จะเห็นตัวอักษร N/P/C/X หรือ A/R/H
