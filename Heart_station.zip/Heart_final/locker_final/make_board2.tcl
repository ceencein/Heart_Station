# ============================================================
# make_board2.tcl  Creates the Vivado project for BOARD 2 in one step
#
# How to use: Vivado start page -> Tools -> Run Tcl Script... -> choose this file
#   (or in the Tcl Console:  source C:/fpga/locker_final/make_board2.tcl )
# The project is created in the folder vivado_board2 next to this script.
# Keep the folder path short, without spaces or Thai letters (e.g. C:/fpga/locker_final).
# ============================================================
set here [file normalize [file dirname [info script]]]

create_project board2 $here/vivado_board2 -part xc7s15ftgb196-1 -force
set_property target_language VHDL [current_project]

# design files: every .vhd in the board2 folder (each file only once)
add_files -norecurse [glob $here/board2/*.vhd]
set_property top board2 [current_fileset]

# pin constraints
add_files -fileset constrs_1 -norecurse $here/board2/board2.xdc

# simulation files (optional, only used by Run Simulation)
add_files -fileset sim_1 -norecurse [list $here/sim/tb_board2_fsm.vhd $here/sim/tb_board2_lcd.vhd $here/sim/tb_board2_servo.vhd $here/sim/tb_uart.vhd]
set_property top tb_board2_fsm [get_filesets sim_1]

# also write a .bin file for flash programming
set_property STEPS.WRITE_BITSTREAM.ARGS.BIN_FILE true [get_runs impl_1]

update_compile_order -fileset sources_1
puts "Project board2 created in $here/vivado_board2 - next: Generate Bitstream"
