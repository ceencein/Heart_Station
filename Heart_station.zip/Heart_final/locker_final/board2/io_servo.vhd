-- ============================================================
-- io_servo.vhd  (board 2)  50 Hz PWM for a servo motor (door latch)
--
--   period 20 ms = 1,000,000 clocks at 50 MHz
--   pulse width pulse_us (microseconds) sets the angle
--     ~1000 us = one end, ~1500 us = center, ~2000 us = other end
--
-- Method: counter runs 0..PERIOD-1, pwm = '1' while counter < width
--         (comparator). width is latched at the start of each period so the
--         pulse never changes in the middle of a period
--
-- Smooth move (generic STEP_US):
--   0  = jump to the new pulse_us at once (servo swings at full speed)
--   >0 = the pulse moves toward pulse_us by at most STEP_US every 20 ms period,
--        e.g. 20 us/period = 1000 us per second. A slower move overshoots less
--        and draws less current. After reset the servo starts at pulse_us directly.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity io_servo is
    generic (
        CLK_HZ  : integer := 50_000_000;
        STEP_US : integer := 0            -- max change per 20 ms period, 0 = instant
    );
    port (
        clk      : in  std_logic;
        rst      : in  std_logic;
        pulse_us : in  unsigned(11 downto 0);
        pwm      : out std_logic
    );
end entity;

architecture rtl of io_servo is
    constant PERIOD     : integer := CLK_HZ / 50;          -- 20 ms
    constant CYC_PER_US : integer := CLK_HZ / 1_000_000;   -- 50

    signal cnt   : integer range 0 to PERIOD - 1 := 0;
    signal width : integer range 0 to 4095 * CYC_PER_US := 0;
    signal cur   : integer range 0 to 4095 := 0;          -- pulse being sent now (us)
    signal first : std_logic := '1';                      -- first period after reset
begin
    process (clk)
        variable nxt : integer range 0 to 4095;
    begin
        if rising_edge(clk) then
            if rst = '1' then
                cnt   <= 0;
                width <= 0;
                cur   <= 0;
                first <= '1';
                pwm   <= '0';
            else
                if cnt >= PERIOD - 1 then
                    cnt <= 0;
                    -- next pulse width: jump, or step toward the target
                    if STEP_US = 0 or first = '1' then
                        nxt := to_integer(pulse_us);
                    elsif cur + STEP_US < to_integer(pulse_us) then
                        nxt := cur + STEP_US;
                    elsif cur - STEP_US > to_integer(pulse_us) then
                        nxt := cur - STEP_US;
                    else
                        nxt := to_integer(pulse_us);
                    end if;
                    first <= '0';
                    cur   <= nxt;
                    width <= nxt * CYC_PER_US;
                else
                    cnt <= cnt + 1;
                end if;

                if cnt < width then pwm <= '1';
                else                pwm <= '0';
                end if;
            end if;
        end if;
    end process;
end architecture;
