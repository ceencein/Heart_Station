-- ============================================================
-- bus_link_b2.vhd  (board 2)  UART link to board 1 + command merge
--
--   uart_rx --> bus_uart_rx --> byte -> command ('N' 'P' 'C' 'X') --+
--   btn_rise (board 2 buttons) ------------------------------------+--> OR --> c_next ...
--                                                                       |
--   after each command: compare state/role/slot before and after        v
--     changed -> 'A',  nothing changed -> 'R'  --> bus_uart_tx --> uart_tx
--   no traffic for HEART_MS -> 'H' (heartbeat, board 1 knows the link is alive)
--
--   Board 2 buttons: right = NEXT, left = PREV, top = CONFIRM, bottom = CANCEL
--   The FSM registers update on the clock edge after the command pulse, so the
--   values are saved at the pulse and compared one clock later.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity bus_link_b2 is
    generic (
        CLK_HZ   : integer := 50_000_000;
        BAUD     : integer := 115_200;
        HEART_MS : integer := 1_000
    );
    port (
        clk       : in  std_logic;
        rst       : in  std_logic;
        uart_rx   : in  std_logic;
        uart_tx   : out std_logic;
        btn_rise  : in  std_logic_vector(3 downto 0);
        -- FSM state, used to decide 'A' or 'R'
        state     : in  unsigned(2 downto 0);
        role      : in  std_logic;
        slot      : in  unsigned(1 downto 0);
        -- commands to the FSM (1-clock pulses)
        c_next    : out std_logic;
        c_prev    : out std_logic;
        c_confirm : out std_logic;
        c_cancel  : out std_logic
    );
end entity;

architecture rtl of bus_link_b2 is
    constant MS : integer := CLK_HZ / 1000;

    signal rx_data  : std_logic_vector(7 downto 0);
    signal rx_valid, rx_ferr : std_logic;
    signal rx_cmd   : std_logic_vector(2 downto 0);
    signal n_i, p_i, c_i, x_i, any_cmd : std_logic;

    signal cmd_d     : std_logic := '0';
    signal snap      : std_logic_vector(5 downto 0) := (others => '0');
    signal now_v     : std_logic_vector(5 downto 0);
    signal pend      : std_logic := '0';
    signal pend_byte : std_logic_vector(7 downto 0) := U_ACK;
    signal ms_cnt    : integer range 0 to MS - 1 := 0;
    signal hb_ms     : integer range 0 to HEART_MS := 0;
    signal tx_send   : std_logic;
    signal tx_byte   : std_logic_vector(7 downto 0);
    signal tx_busy, tx_done : std_logic;
begin
    -- ---------- Receive: byte -> command, OR with the board 2 buttons ----------
    u_rx : entity work.bus_uart_rx
        generic map (CLK_HZ => CLK_HZ, BAUD => BAUD)
        port map (clk => clk, rst => rst, rx => uart_rx,
                  data => rx_data, valid => rx_valid, ferr => rx_ferr);

    rx_cmd <= byte2cmd(rx_data);
    n_i <= '1' when (rx_valid = '1' and rx_cmd = CMD_NEXT)    or btn_rise(3) = '1' else '0';
    p_i <= '1' when (rx_valid = '1' and rx_cmd = CMD_PREV)    or btn_rise(2) = '1' else '0';
    c_i <= '1' when (rx_valid = '1' and rx_cmd = CMD_CONFIRM) or btn_rise(0) = '1' else '0';
    x_i <= '1' when (rx_valid = '1' and rx_cmd = CMD_CANCEL)  or btn_rise(1) = '1' else '0';

    c_next <= n_i; c_prev <= p_i; c_confirm <= c_i; c_cancel <= x_i;
    any_cmd <= n_i or p_i or c_i or x_i;

    -- ---------- Reply 'A' / 'R' + heartbeat timer ----------
    now_v <= std_logic_vector(state) & role & std_logic_vector(slot);

    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                cmd_d  <= '0';
                pend   <= '0';
                ms_cnt <= 0;
                hb_ms  <= 0;
            else
                cmd_d <= any_cmd;
                if any_cmd = '1' then
                    snap <= now_v;                    -- values before the command
                end if;

                if cmd_d = '1' then                   -- result is visible now
                    pend <= '1';
                    if now_v /= snap then pend_byte <= U_ACK;
                    else                  pend_byte <= U_REJECT; end if;
                elsif tx_send = '1' then
                    pend <= '0';
                end if;

                if tx_send = '1' then
                    hb_ms <= 0;
                elsif ms_cnt = MS - 1 and hb_ms < HEART_MS then
                    hb_ms <= hb_ms + 1;
                end if;
                if ms_cnt = MS - 1 then ms_cnt <= 0; else ms_cnt <= ms_cnt + 1; end if;
            end if;
        end if;
    end process;

    -- ---------- Transmit: a waiting reply first, otherwise the heartbeat ----------
    tx_send <= '1' when tx_busy = '0' and cmd_d = '0' and (pend = '1' or hb_ms = HEART_MS) else '0';
    tx_byte <= pend_byte when pend = '1' else U_HEART;

    u_tx : entity work.bus_uart_tx
        generic map (CLK_HZ => CLK_HZ, BAUD => BAUD)
        port map (clk => clk, rst => rst, send => tx_send, data => tx_byte,
                  tx => uart_tx, busy => tx_busy, done => tx_done);
end architecture;
