-- ============================================================
-- io_display.vhd  (board 2)  LCD + 7-segment
--
--   state / role / slot / occ / done_ok --> ctrl_text --line1, line2--> io_lcd  --> LCD (J2)
--                                                    --sym3..sym0---> io_seg7 --> 7-segment
--
--   ctrl_text : text and symbols for each FSM state (in ctrl_fsm.vhd)
--   io_lcd    : HD44780 16x2 parallel driver
--   io_seg7   : 4-digit multiplexed 7-segment driver
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity io_display is
    generic (
        CLK_HZ         : integer := 50_000_000;
        LEFT_IS_DIGIT0 : boolean := true
    );
    port (
        clk           : in  std_logic;
        rst           : in  std_logic;
        state         : in  unsigned(2 downto 0);
        role          : in  std_logic;
        slot          : in  unsigned(1 downto 0);
        occ           : in  std_logic_vector(2 downto 0);
        done_ok       : in  std_logic;
        lcd_data      : out std_logic_vector(7 downto 0);
        lcd_rs        : out std_logic;
        lcd_e         : out std_logic;
        digit         : out std_logic_vector(3 downto 0);
        Seven_Segment : out std_logic_vector(7 downto 0)
    );
end entity;

architecture rtl of io_display is
    signal line1, line2 : lcd_line_t;
    signal sym3, sym2, sym1, sym0 : unsigned(3 downto 0);
begin
    u_txt : entity work.ctrl_text
        port map (state => state, role => role, slot => slot, occ => occ, done_ok => done_ok,
                  line1 => line1, line2 => line2,
                  sym3 => sym3, sym2 => sym2, sym1 => sym1, sym0 => sym0);

    u_lcd : entity work.io_lcd
        generic map (CLK_HZ => CLK_HZ)
        port map (clk => clk, rst => rst, line1 => line1, line2 => line2,
                  lcd_data => lcd_data, lcd_rs => lcd_rs, lcd_e => lcd_e);

    u_seg : entity work.io_seg7
        generic map (LEFT_IS_DIGIT0 => LEFT_IS_DIGIT0)
        port map (clk => clk, rst => rst,
                  sym3 => sym3, sym2 => sym2, sym1 => sym1, sym0 => sym0,
                  digit => digit, Seven_Segment => Seven_Segment);
end architecture;
