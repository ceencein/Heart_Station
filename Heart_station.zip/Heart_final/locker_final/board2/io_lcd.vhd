-- ============================================================
-- io_lcd.vhd  (board 2)  Drives the 16x2 LCD (HD44780) plugged into J2 on the EDGE board
--
-- The J2 LCD is wired as an 8-bit parallel bus (per the vendor XDC):
--   lcd_data(7 downto 0) = LCD D7..D0  (pins shared with onboard LEDs D2-D9)
--   lcd_rs               = '0' command, '1' character
--   lcd_e                = Enable, the LCD latches data on the falling edge of E
--   R/W is tied to GND on the board -> write only, the busy flag cannot be read,
--   so every command is followed by a fixed wait that is long enough
--
-- Timing of one byte:
--   rs/data  ===X========= new value ==========X===
--   e        _____/~~~~~~~~\__________________
--               |T_SU| T_EN |  T_WAIT (50 us or 2 ms)
--
-- Job table (seq):
--   0..2   : 0x38 three times (8-bit, 2 lines), waits 5 ms / 1 ms / 1 ms
--   3..6   : 0x38, 0x0C (display on, no cursor), 0x06 (cursor moves right), 0x01 (clear, 2 ms)
--   7      : 0x80 go to line 1,   8..23  : the 16 characters of line1
--   24     : 0xC0 go to line 2,   25..40 : the 16 characters of line2
--   then loop back to seq 7 (the whole screen is rewritten every ~2 ms,
--   so the text follows the inputs automatically)
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity io_lcd is
    generic (
        CLK_HZ : integer := 50_000_000
    );
    port (
        clk      : in  std_logic;
        rst      : in  std_logic;
        line1    : in  lcd_line_t;
        line2    : in  lcd_line_t;
        lcd_data : out std_logic_vector(7 downto 0);
        lcd_rs   : out std_logic;
        lcd_e    : out std_logic
    );
end entity;

architecture rtl of io_lcd is
    constant US      : integer := CLK_HZ / 1_000_000;   -- clocks per 1 us
    constant T_PWR   : integer := 50_000 * US;           -- wait 50 ms for LCD power
    constant T_SU    : integer := 1 * US;                -- RS/data setup before E rises
    constant T_EN    : integer := 2 * US;                -- E pulse width (min 0.45 us)
    constant T_SHORT : integer := 50 * US;               -- normal command/character (needs 37 us)

    type state_t is (S_PWR, S_LOAD, S_SU, S_EN, S_WAIT);
    signal st    : state_t := S_PWR;
    signal tmr   : integer range 0 to T_PWR := 0;
    signal seq   : integer range 0 to 40 := 0;

    -- current job from the table
    signal j_rs   : std_logic;
    signal j_val  : std_logic_vector(7 downto 0);
    signal j_wait : integer range 0 to T_PWR;

    signal data_r : std_logic_vector(7 downto 0) := (others => '0');
    signal rs_r   : std_logic := '0';
    signal e_r    : std_logic := '0';
    signal wait_r : integer range 0 to T_PWR := 0;
begin
    lcd_data <= data_r;
    lcd_rs   <= rs_r;
    lcd_e    <= e_r;

    -- ---------- Job table (combinational) ----------
    process (seq, line1, line2)
        variable ci : integer range 0 to 15;
    begin
        j_rs   <= '0';
        j_val  <= x"00";
        j_wait <= T_SHORT;
        case seq is
            when 0  => j_val <= x"38"; j_wait <= 5_000 * US;
            when 1  => j_val <= x"38"; j_wait <= 1_000 * US;
            when 2  => j_val <= x"38"; j_wait <= 1_000 * US;
            when 3  => j_val <= x"38";
            when 4  => j_val <= x"0C";
            when 5  => j_val <= x"06";
            when 6  => j_val <= x"01"; j_wait <= 2_000 * US;   -- clear needs 1.52 ms
            when 7  => j_val <= x"80";
            when 24 => j_val <= x"C0";
            when 8 to 23 =>
                j_rs  <= '1';
                ci    := seq - 8;
                j_val <= line1(8 * (15 - ci) + 7 downto 8 * (15 - ci));
            when others =>                                         -- 25..40
                j_rs  <= '1';
                ci    := seq - 25;
                j_val <= line2(8 * (15 - ci) + 7 downto 8 * (15 - ci));
        end case;
    end process;

    -- ---------- Sender ----------
    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                st <= S_PWR; tmr <= 0; seq <= 0;
                data_r <= (others => '0'); rs_r <= '0'; e_r <= '0'; wait_r <= 0;
            else
                case st is
                    when S_PWR =>                                  -- wait for the LCD
                        if tmr >= T_PWR - 1 then tmr <= 0; st <= S_LOAD;
                        else tmr <= tmr + 1; end if;

                    when S_LOAD =>                                 -- put RS + data
                        rs_r   <= j_rs;
                        data_r <= j_val;
                        wait_r <= j_wait;
                        e_r    <= '0';
                        tmr    <= 0;
                        st     <= S_SU;

                    when S_SU =>                                   -- setup, then raise E
                        if tmr >= T_SU - 1 then tmr <= 0; e_r <= '1'; st <= S_EN;
                        else tmr <= tmr + 1; end if;

                    when S_EN =>                                   -- hold E, then drop it (LCD latches)
                        if tmr >= T_EN - 1 then tmr <= 0; e_r <= '0'; st <= S_WAIT;
                        else tmr <= tmr + 1; end if;

                    when S_WAIT =>                                 -- wait for the LCD to finish
                        if tmr >= wait_r - 1 then
                            tmr <= 0;
                            if seq = 40 then seq <= 7; else seq <= seq + 1; end if;
                            st <= S_LOAD;
                        else
                            tmr <= tmr + 1;
                        end if;
                end case;
            end if;
        end if;
    end process;
end architecture;
