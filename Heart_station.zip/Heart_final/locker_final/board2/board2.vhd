-- ============================================================
-- board2.vhd  TOP OF BOARD 2 : main controller of the 3-slot sharing locker
--
-- This top only connects 6 blocks (no logic of its own):
--
--   pb(4) ----------> [sys_reset] -------------------------------------> rst (all blocks)
--   pb(3:0) --------> [io_buttons] --btn_rise--+
--                                              v
--   board 1 --uart_rx--> [bus_link_b2] --c_next/prev/confirm/cancel--> [ctrl_fsm]
--   board 1 <-uart_tx--      ^  reply 'A'/'R', heartbeat 'H'              |
--                            +---------------- state, role, slot ---------+
--                                                                          |
--                    state, role, slot, occ, done_ok  +--------------------+
--                                                     v                    v unlock, occ
--                                              [io_display]           [io_slots]
--                                               LCD, 7-segment         servo x3, slot LEDs
--
--   sys_reset   : power-on reset + center button (watchdog off on this board)
--   io_buttons  : 4 x io_debounce (board 2 buttons can replace board 1 for testing)
--   bus_link_b2 : UART receive / reply / heartbeat (bus_uart_rx, bus_uart_tx)
--   ctrl_fsm    : 5-state FSM + slot occupancy memory
--   io_display  : ctrl_text + io_lcd + io_seg7
--   io_slots    : 3 x io_servo (angles in degrees) + slot LED select
--
-- FSM : 0 IDLE -> 1 ROLE (giver / receiver) -> 2 ITEM (slot 1-3)
--       -> 3 PROCESS (slot unlocked) -> 4 DONE (locked, thank you) -> 0 IDLE
-- UART: J5 pin4 GND, pin5 RX <- board 1 pin5, pin6 TX -> board 1 pin6 (115200, 8N1)
-- Buttons : right = NEXT, left = PREV, top = CONFIRM, bottom = CANCEL, center = reset
-- 7-segment : [state 0-4] [role G / r] [-] [slot 1-3]
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity board2 is
    generic (
        CLK_HZ          : integer := 50_000_000;
        IDLE_S          : integer := 30;       -- ROLE / ITEM without a gesture -> IDLE (s)
        DONE_MS         : integer := 3_000;    -- thank-you message time (ms)
        -- ---- latch servo angles (degrees, 0-180) ----
        SERVO_LOCK_DEG   : integer := 45;      -- angle where the latch blocks the door
        SERVO_UNLOCK_DEG : integer := 135;     -- angle where the latch is pulled back
        SERVO_SPEED_DPS  : integer := 180;     -- turning speed in degrees per second, 0 = full speed
        -- ---- servo calibration: pulse width at 0 and 180 degrees ----
        SERVO_0DEG_US    : integer := 500;     -- SG90 typical 500 us
        SERVO_180DEG_US  : integer := 2400;    -- SG90 typical 2400 us
        LEFT_IS_DIGIT0  : boolean := true;     -- 7-segment: digit[0] is the left-most digit
        -- ---- UART link ----
        BAUD            : integer := 115_200;
        HEART_MS        : integer := 1_000     -- heartbeat period
    );
    port (
        clk           : in    std_logic;       -- 50 MHz
        pb            : in    std_logic_vector(4 downto 0);
        uart_rx       : in    std_logic;       -- J5 pin5 <- board 1 J5 pin5
        uart_tx       : out   std_logic;       -- J5 pin6 -> board 1 J5 pin6
        servo         : out   std_logic_vector(2 downto 0);
        slot_led      : out   std_logic_vector(2 downto 0);   -- cabinet LEDs, slot 1-3
        lcd_data      : out   std_logic_vector(7 downto 0);   -- LCD on J2
        lcd_rs        : out   std_logic;
        lcd_e         : out   std_logic;
        digit         : out   std_logic_vector(3 downto 0);
        Seven_Segment : out   std_logic_vector(7 downto 0)
    );
end entity;

architecture rtl of board2 is
    signal rst, por : std_logic;
    signal btn_rise : std_logic_vector(3 downto 0);
    signal c_next, c_prev, c_confirm, c_cancel : std_logic;
    signal state    : unsigned(2 downto 0);
    signal role     : std_logic;
    signal slot     : unsigned(1 downto 0);
    signal unlock   : std_logic_vector(2 downto 0);
    signal occ      : std_logic_vector(2 downto 0);
    signal done_ok  : std_logic;
begin
    u_rst : entity work.sys_reset
        generic map (CLK_HZ => CLK_HZ, WDT_S => 0)
        port map (clk => clk, btn => pb(4), kick => '0', rst => rst, por => por);

    u_btn : entity work.io_buttons
        generic map (CLK_HZ => CLK_HZ)
        port map (clk => clk, rst => rst, pb => pb(3 downto 0), rise => btn_rise);

    u_link : entity work.bus_link_b2
        generic map (CLK_HZ => CLK_HZ, BAUD => BAUD, HEART_MS => HEART_MS)
        port map (clk => clk, rst => rst, uart_rx => uart_rx, uart_tx => uart_tx,
                  btn_rise => btn_rise, state => state, role => role, slot => slot,
                  c_next => c_next, c_prev => c_prev, c_confirm => c_confirm, c_cancel => c_cancel);

    u_fsm : entity work.ctrl_fsm
        generic map (CLK_HZ => CLK_HZ, IDLE_S => IDLE_S, DONE_MS => DONE_MS)
        port map (clk => clk, rst => rst,
                  c_next => c_next, c_prev => c_prev, c_confirm => c_confirm, c_cancel => c_cancel,
                  state => state, role => role, slot => slot, unlock => unlock,
                  occ => occ, done_ok => done_ok);

    u_disp : entity work.io_display
        generic map (CLK_HZ => CLK_HZ, LEFT_IS_DIGIT0 => LEFT_IS_DIGIT0)
        port map (clk => clk, rst => rst,
                  state => state, role => role, slot => slot, occ => occ, done_ok => done_ok,
                  lcd_data => lcd_data, lcd_rs => lcd_rs, lcd_e => lcd_e,
                  digit => digit, Seven_Segment => Seven_Segment);

    u_slots : entity work.io_slots
        generic map (CLK_HZ => CLK_HZ,
                     SERVO_LOCK_DEG => SERVO_LOCK_DEG, SERVO_UNLOCK_DEG => SERVO_UNLOCK_DEG,
                     SERVO_SPEED_DPS => SERVO_SPEED_DPS,
                     SERVO_0DEG_US => SERVO_0DEG_US, SERVO_180DEG_US => SERVO_180DEG_US)
        port map (clk => clk, rst => rst, unlock => unlock, occ => occ,
                  state => state, slot => slot, servo => servo, slot_led => slot_led);
end architecture;
