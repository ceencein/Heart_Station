## ============================================================
## board2.xdc - BOARD 2 (3-slot sharing locker, top: board2)  EDGE Spartan-7 XC7S15
## Every pin checked against the vendor file EDGE_Spartan7_Pins_Details.xdc
## ============================================================

## Clock 50 MHz
set_property -dict { PACKAGE_PIN H11 IOSTANDARD LVCMOS33 } [get_ports { clk }];
create_clock -period 20.000 -name sys_clk [get_ports { clk }];

## Push buttons (pressed = 1)
set_property -dict { PACKAGE_PIN J13 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[0] }]; # top    = CONFIRM
set_property -dict { PACKAGE_PIN L13 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[1] }]; # bottom = CANCEL
set_property -dict { PACKAGE_PIN J14 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[2] }]; # left   = PREV
set_property -dict { PACKAGE_PIN J11 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[3] }]; # right  = NEXT
set_property -dict { PACKAGE_PIN J12 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[4] }]; # center = RESET

## 7-segment, 4 digits (common anode); vendor: digit[0] = left-most
## Note: segment pins are shared with LEDs D10-D17 -> remove jumper J9
set_property -dict { PACKAGE_PIN H4 IOSTANDARD LVCMOS33 } [get_ports { digit[0] }];
set_property -dict { PACKAGE_PIN H3 IOSTANDARD LVCMOS33 } [get_ports { digit[1] }];
set_property -dict { PACKAGE_PIN H2 IOSTANDARD LVCMOS33 } [get_ports { digit[2] }];
set_property -dict { PACKAGE_PIN H1 IOSTANDARD LVCMOS33 } [get_ports { digit[3] }];
set_property -dict { PACKAGE_PIN L3 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[7] }]; # A
set_property -dict { PACKAGE_PIN P4 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[6] }]; # B
set_property -dict { PACKAGE_PIN P2 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[5] }]; # C
set_property -dict { PACKAGE_PIN M3 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[4] }]; # D
set_property -dict { PACKAGE_PIN M1 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[3] }]; # E
set_property -dict { PACKAGE_PIN J4 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[2] }]; # F
set_property -dict { PACKAGE_PIN K4 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[1] }]; # G
set_property -dict { PACKAGE_PIN J2 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[0] }]; # DP

## LCD 16x2 in J2 (8-bit parallel, R/W tied to GND on the board)
## Note: data[0..7] share pins with LEDs D2-D9 (reverse order) -> remove J4 to turn those LEDs off
set_property -dict { PACKAGE_PIN M4  IOSTANDARD LVCMOS33 } [get_ports { lcd_data[0] }];
set_property -dict { PACKAGE_PIN L5  IOSTANDARD LVCMOS33 } [get_ports { lcd_data[1] }];
set_property -dict { PACKAGE_PIN P11 IOSTANDARD LVCMOS33 } [get_ports { lcd_data[2] }];
set_property -dict { PACKAGE_PIN N11 IOSTANDARD LVCMOS33 } [get_ports { lcd_data[3] }];
set_property -dict { PACKAGE_PIN P13 IOSTANDARD LVCMOS33 } [get_ports { lcd_data[4] }];
set_property -dict { PACKAGE_PIN M14 IOSTANDARD LVCMOS33 } [get_ports { lcd_data[5] }];
set_property -dict { PACKAGE_PIN M12 IOSTANDARD LVCMOS33 } [get_ports { lcd_data[6] }];
set_property -dict { PACKAGE_PIN K12 IOSTANDARD LVCMOS33 } [get_ports { lcd_data[7] }];
set_property -dict { PACKAGE_PIN P5  IOSTANDARD LVCMOS33 } [get_ports { lcd_e }];
set_property -dict { PACKAGE_PIN M5  IOSTANDARD LVCMOS33 } [get_ports { lcd_rs }];

## ---------------- Expansion connector J5 (20 pins) ----------------
## pin1 = 5V, pin2 = NC, pin3 = 3V3, pin4 = GND, pin5-20 = I/O

## UART link with board 1 (115200 baud, 8N1) - J5 pins 4, 5, 6 straight across to board 1
set_property -dict { PACKAGE_PIN L14 IOSTANDARD LVCMOS33 PULLUP true } [get_ports { uart_rx }]; # J5 pin5 <- board 1 pin5 (its TX)
set_property -dict { PACKAGE_PIN M13 IOSTANDARD LVCMOS33 } [get_ports { uart_tx }];              # J5 pin6 -> board 1 pin6 (its RX)
## J5 pin7 (H14), pin8 (H13) now free

## J5 pin9 (F11) unused

## Latch servo signal wires (servo 5 V power from an external supply, common GND)
set_property -dict { PACKAGE_PIN G11 IOSTANDARD LVCMOS33 } [get_ports { servo[0] }];   # J5 pin10  slot 1
set_property -dict { PACKAGE_PIN C14 IOSTANDARD LVCMOS33 } [get_ports { servo[1] }];   # J5 pin11  slot 2
set_property -dict { PACKAGE_PIN D14 IOSTANDARD LVCMOS33 } [get_ports { servo[2] }];   # J5 pin12  slot 3

## Cabinet slot LEDs (220-330 ohm series resistor on every LED)
set_property -dict { PACKAGE_PIN E13 IOSTANDARD LVCMOS33 } [get_ports { slot_led[0] }]; # J5 pin13  slot 1
set_property -dict { PACKAGE_PIN F13 IOSTANDARD LVCMOS33 } [get_ports { slot_led[1] }]; # J5 pin14  slot 2
set_property -dict { PACKAGE_PIN F14 IOSTANDARD LVCMOS33 } [get_ports { slot_led[2] }]; # J5 pin15  slot 3

## J5 pin16-20 (G14, D13, D12, E12, F12) unused

## Config
set_property CFGBVS VCCO [current_design];
set_property CONFIG_VOLTAGE 3.3 [current_design];
