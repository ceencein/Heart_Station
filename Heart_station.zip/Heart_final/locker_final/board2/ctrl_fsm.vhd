-- ============================================================
-- ctrl_fsm.vhd  (board 2)  locker control
--
-- This file holds 2 entities:
--   ctrl_fsm  : main 5-state FSM (IDLE / ROLE / ITEM / PROCESS / DONE)
--               + slot occupancy memory (which slots hold an item)
--   ctrl_text : LCD text + 7-segment symbols for each state
--
-- ------------------------------------------------------------
-- ctrl_fsm  Main FSM of the 3-slot touchless sharing locker
--
-- Each slot has a hinged door and a latch pushed by a servo. The servo only
-- releases the latch; the user opens the door by hand. One slot at a time.
--
-- Slot occupancy : occ(i) = '1' -> slot i holds an item, '0' -> empty
--   all slots start empty after power-up / reset
--   GIVER    may only choose EMPTY slots, and the slot becomes FULL when he confirms
--   RECEIVER may only choose FULL  slots, and the slot becomes EMPTY when he confirms
--   (no sensor inside the slots: the system trusts the user's confirm)
--
-- 5 states:
--   0 IDLE    : all slots locked
--               NEXT / PREV / CONFIRM -> ROLE        (CANCEL does nothing)
--   1 ROLE    : NEXT / PREV toggle GIVER <-> RECEIVER
--               CONFIRM -> ITEM, but only if this role has a slot to use
--                 (giver: at least one empty slot, receiver: at least one full slot)
--               CANCEL, or no gesture for IDLE_S seconds -> IDLE
--   2 ITEM    : starts on the first usable slot
--               NEXT / PREV jump to the next / previous usable slot (others are skipped)
--               CONFIRM -> PROCESS (latch of that slot released)
--               CANCEL -> back to ROLE,  no gesture for IDLE_S seconds -> IDLE
--   3 PROCESS : chosen slot unlocked, user puts in (giver) / takes out (receiver)
--               CONFIRM -> DONE, latch locked, occupancy updated (done_ok = '1')
--               CANCEL  -> DONE, latch locked, occupancy NOT changed (done_ok = '0')
--               no auto-lock, NEXT / PREV ignored (no second slot can open)
--   4 DONE    : all locked, message for DONE_MS, every command ignored, then IDLE
--
-- unlock(2 downto 0) is one-hot: the bit that is '1' = latch of that slot released.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity ctrl_fsm is
    generic (
        CLK_HZ  : integer := 50_000_000;
        IDLE_S  : integer := 30;              -- seconds without a gesture in ROLE / ITEM -> IDLE
        DONE_MS : integer := 3_000            -- how long the DONE message is shown
    );
    port (
        clk       : in  std_logic;
        rst       : in  std_logic;
        c_next    : in  std_logic;
        c_prev    : in  std_logic;
        c_confirm : in  std_logic;
        c_cancel  : in  std_logic;

        state     : out unsigned(2 downto 0);
        role      : out std_logic;                    -- ROLE_GIVER / ROLE_RECEIVER
        slot      : out unsigned(1 downto 0);         -- 0..2 (shown as 1..3)
        unlock    : out std_logic_vector(2 downto 0); -- one-hot: slot whose latch is released
        occ       : out std_logic_vector(2 downto 0); -- '1' = slot holds an item
        done_ok   : out std_logic                     -- DONE reached with CONFIRM (not CANCEL)
    );
end entity;

architecture rtl of ctrl_fsm is

    constant T_IDLE : integer := IDLE_S * CLK_HZ;
    constant T_DONE : integer := DONE_MS * (CLK_HZ / 1000);

    function max(a, b : integer) return integer is
    begin
        if a > b then return a; else return b; end if;
    end function;

    signal st       : unsigned(2 downto 0) := ST_IDLE;
    signal role_r   : std_logic := ROLE_GIVER;
    signal slot_r   : unsigned(1 downto 0) := "00";
    signal unlock_r : std_logic_vector(2 downto 0) := "000";
    signal occ_r    : std_logic_vector(2 downto 0) := "000";
    signal ok_r     : std_logic := '0';
    signal tmr      : integer range 0 to max(T_IDLE, T_DONE) := 0;

    signal any_cmd  : std_logic;
    signal usable   : std_logic_vector(2 downto 0);   -- slots this role may choose
    signal any_use  : std_logic;

    function onehot(s : unsigned(1 downto 0)) return std_logic_vector is
    begin
        case s is
            when "00"   => return "001";
            when "01"   => return "010";
            when others => return "100";
        end case;
    end function;

    -- first usable slot (0, 1, 2), or 0 if none
    function first_slot(u : std_logic_vector(2 downto 0)) return unsigned is
    begin
        if    u(0) = '1' then return "00";
        elsif u(1) = '1' then return "01";
        elsif u(2) = '1' then return "10";
        else                  return "00";
        end if;
    end function;

    -- next / previous usable slot, wrapping 1 -> 2 -> 3 -> 1; stays put if none other
    function step_slot(s : unsigned(1 downto 0); u : std_logic_vector(2 downto 0);
                       up : boolean) return unsigned is
        variable c : integer;
    begin
        for k in 1 to 3 loop
            if up then c := (to_integer(s) + k) mod 3;
            else       c := (to_integer(s) + 3 - k) mod 3;
            end if;
            if u(c) = '1' then
                return to_unsigned(c, 2);
            end if;
        end loop;
        return s;
    end function;

begin
    state   <= st;
    role    <= role_r;
    slot    <= slot_r;
    unlock  <= unlock_r;
    occ     <= occ_r;
    done_ok <= ok_r;

    any_cmd <= c_next or c_prev or c_confirm or c_cancel;

    -- giver needs an empty slot, receiver needs a full slot
    usable  <= not occ_r when role_r = ROLE_GIVER else occ_r;
    any_use <= usable(0) or usable(1) or usable(2);

    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                st       <= ST_IDLE;
                role_r   <= ROLE_GIVER;
                slot_r   <= "00";
                unlock_r <= "000";
                occ_r    <= "000";                    -- all slots empty
                ok_r     <= '0';
                tmr      <= 0;
            else
                case st is
                -- ================= 0 IDLE =================
                when ST_IDLE =>
                    unlock_r <= "000";
                    tmr      <= 0;
                    if (c_next or c_prev or c_confirm) = '1' then
                        role_r <= ROLE_GIVER;
                        slot_r <= "00";
                        st     <= ST_ROLE;
                    end if;

                -- ================= 1 ROLE : giver / receiver =================
                when ST_ROLE =>
                    unlock_r <= "000";
                    if any_cmd = '1' then tmr <= 0;
                    elsif tmr < T_IDLE then tmr <= tmr + 1; end if;

                    if (c_next or c_prev) = '1' then
                        role_r <= not role_r;
                    elsif c_confirm = '1' then
                        if any_use = '1' then             -- only if this role has a slot
                            slot_r <= first_slot(usable);
                            st     <= ST_ITEM;
                        end if;                           -- else stay, LCD says why
                    elsif c_cancel = '1' or tmr >= T_IDLE then
                        st <= ST_IDLE;
                    end if;

                -- ================= 2 ITEM : choose a usable slot =================
                when ST_ITEM =>
                    unlock_r <= "000";
                    if any_cmd = '1' then tmr <= 0;
                    elsif tmr < T_IDLE then tmr <= tmr + 1; end if;

                    if c_next = '1' then
                        slot_r <= step_slot(slot_r, usable, true);
                    elsif c_prev = '1' then
                        slot_r <= step_slot(slot_r, usable, false);
                    elsif c_confirm = '1' then
                        unlock_r <= onehot(slot_r);           -- release the chosen latch
                        st       <= ST_PROCESS;
                    elsif c_cancel = '1' then
                        st <= ST_ROLE;                        -- one step back
                    elsif tmr >= T_IDLE then
                        st <= ST_IDLE;
                    end if;

                -- ================= 3 PROCESS : slot unlocked =================
                when ST_PROCESS =>
                    tmr <= 0;
                    if c_confirm = '1' then                   -- transaction done
                        unlock_r <= "000";
                        ok_r     <= '1';
                        if role_r = ROLE_GIVER then
                            occ_r(to_integer(slot_r)) <= '1'; -- item put in
                        else
                            occ_r(to_integer(slot_r)) <= '0'; -- item taken out
                        end if;
                        st <= ST_DONE;
                    elsif c_cancel = '1' then                 -- changed mind: lock, no change
                        unlock_r <= "000";
                        ok_r     <= '0';
                        st       <= ST_DONE;
                    end if;

                -- ================= 4 DONE : locked, message, then IDLE =================
                when others =>
                    unlock_r <= "000";                        -- all commands ignored here
                    if tmr >= T_DONE then
                        tmr <= 0;
                        st  <= ST_IDLE;
                    else
                        tmr <= tmr + 1;
                    end if;
                end case;
            end if;
        end if;
    end process;

end architecture;


-- ============================================================
-- ctrl_text  (board 2)  LCD text + 7-segment symbols, 5 states
--
-- LCD 16x2 (CW = clockwise = CONFIRM, CCW = counter-clockwise = CANCEL):
--   0 IDLE    : " Drop and Pick !" / "SWIPE  ITEMS:2/3"   (number of full slots)
--   1 ROLE    : "ROLE: GIVER     " / "<SWIPE> CW=OK   "
--               "ROLE: RECEIVER  "
--               line 2 when this role has no slot to use:
--                 giver    -> "ALL SLOTS FULL  "
--                 receiver -> "NO ITEMS YET    "
--   2 ITEM    : "SELECT SLOT: 2  " / "<SWIPE> CW=OPEN "
--   3 PROCESS : "SLOT 2 UNLOCKED " / "PUT ITEM, CW=OK "   (giver)
--                                    "TAKE ITEM,CW=OK "   (receiver)
--   4 DONE    : "SLOT 2 LOCKED   " / "THANK YOU GIVER!"   (giver,    confirmed)
--                                    "HAVE A NICE DAY "   (receiver, confirmed)
--                                    "CANCELLED       "   (CCW, nothing changed)
--
-- 7-segment (left -> right): [state 0-4] [role G / r] [-] [slot 1-3]
--   IDLE shows "0 - - -", ROLE shows "1 G - -"
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity ctrl_text is
    port (
        state   : in  unsigned(2 downto 0);
        role    : in  std_logic;
        slot    : in  unsigned(1 downto 0);
        occ     : in  std_logic_vector(2 downto 0);
        done_ok : in  std_logic;
        line1   : out lcd_line_t;
        line2   : out lcd_line_t;
        sym3    : out unsigned(3 downto 0);   -- left-most digit
        sym2    : out unsigned(3 downto 0);
        sym1    : out unsigned(3 downto 0);
        sym0    : out unsigned(3 downto 0)    -- right-most digit
    );
end entity;

architecture rtl of ctrl_text is
    signal slot_num : unsigned(3 downto 0);
    signal n_full   : unsigned(3 downto 0);   -- number of full slots 0-3
    signal is_giver : boolean;
    signal any_use  : boolean;                -- this role has a slot to use
begin
    slot_num <= resize(slot, 4) + 1;
    is_giver <= role = ROLE_GIVER;

    n_full <= ("000" & occ(0)) + ("000" & occ(1)) + ("000" & occ(2));
    any_use <= (occ /= "111") when is_giver else (occ /= "000");

    -- ---------- LCD ----------
    process (state, slot_num, is_giver, n_full, any_use, done_ok)
    begin
        case state is
            when ST_IDLE =>
                line1 <= str2slv(" Drop and Pick !");
                line2 <= str2slv("SWIPE  ITEMS:") & asc(n_full) & str2slv("/3");
            when ST_ROLE =>
                if is_giver then line1 <= str2slv("ROLE: GIVER     ");
                else             line1 <= str2slv("ROLE: RECEIVER  "); end if;
                if any_use then
                    line2 <= str2slv("<SWIPE> CW=OK   ");
                elsif is_giver then
                    line2 <= str2slv("ALL SLOTS FULL  ");
                else
                    line2 <= str2slv("NO ITEMS YET    ");
                end if;
            when ST_ITEM =>
                line1 <= str2slv("SELECT SLOT: ") & asc(slot_num) & str2slv("  ");
                line2 <= str2slv("<SWIPE> CW=OPEN ");
            when ST_PROCESS =>
                line1 <= str2slv("SLOT ") & asc(slot_num) & str2slv(" UNLOCKED ");
                if is_giver then line2 <= str2slv("PUT ITEM, CW=OK ");
                else             line2 <= str2slv("TAKE ITEM,CW=OK "); end if;
            when others =>  -- DONE
                line1 <= str2slv("SLOT ") & asc(slot_num) & str2slv(" LOCKED   ");
                if done_ok = '0' then line2 <= str2slv("CANCELLED       ");
                elsif is_giver   then line2 <= str2slv("THANK YOU GIVER!");
                else                  line2 <= str2slv("HAVE A NICE DAY "); end if;
        end case;
    end process;

    -- ---------- 7-segment ----------
    sym3 <= resize(state, 4);
    sym2 <= SYM_DASH when state = ST_IDLE else
            SYM_G    when is_giver        else
            SYM_R;
    sym1 <= SYM_DASH;
    sym0 <= SYM_DASH when state = ST_IDLE or state = ST_ROLE else slot_num;
end architecture;
