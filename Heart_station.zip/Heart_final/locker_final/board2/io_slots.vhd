-- ============================================================
-- io_slots.vhd  (board 2)  Latch servos + cabinet slot LEDs
--
--   unlock(i) --> angle (lock / unlock) --> io_servo x3 --> servo(2:0)
--   unlock / state / slot / occ --> LED select --> slot_led(2:0)
--
-- Servo angles are set in degrees; the pulse widths are worked out at synthesis:
--   pulse = SERVO_0DEG_US + deg x (SERVO_180DEG_US - SERVO_0DEG_US) / 180
--   default 45 deg = 975 us (lock), 135 deg = 1925 us (unlock)
--   SERVO_SPEED_DPS > 0 : the servo moves smoothly at that speed (degrees / second)
--
-- Slot LEDs:
--   steady on = latch of that slot released
--   blinking  = slot being chosen in state ITEM (~0.34 s at 50 MHz)
--   dim       = locked, slot holds an item (1/8 duty at ~760 Hz, no flicker)
--   off       = locked, slot empty
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity io_slots is
    generic (
        CLK_HZ           : integer := 50_000_000;
        SERVO_LOCK_DEG   : integer := 45;
        SERVO_UNLOCK_DEG : integer := 135;
        SERVO_SPEED_DPS  : integer := 180;
        SERVO_0DEG_US    : integer := 500;
        SERVO_180DEG_US  : integer := 2400
    );
    port (
        clk      : in  std_logic;
        rst      : in  std_logic;
        unlock   : in  std_logic_vector(2 downto 0);
        occ      : in  std_logic_vector(2 downto 0);
        state    : in  unsigned(2 downto 0);
        slot     : in  unsigned(1 downto 0);
        servo    : out std_logic_vector(2 downto 0);
        slot_led : out std_logic_vector(2 downto 0)
    );
end entity;

architecture rtl of io_slots is
    -- degrees -> microseconds (computed once at synthesis, no hardware divider)
    constant US_SPAN   : integer := SERVO_180DEG_US - SERVO_0DEG_US;
    constant LOCK_US   : integer := SERVO_0DEG_US + SERVO_LOCK_DEG   * US_SPAN / 180;
    constant UNLOCK_US : integer := SERVO_0DEG_US + SERVO_UNLOCK_DEG * US_SPAN / 180;
    -- degrees per second -> microseconds per 20 ms period (at least 1 when enabled)
    function calc_step(dps : integer) return integer is
    begin
        if dps <= 0 then return 0; end if;
        if dps * US_SPAN / 180 / 50 < 1 then return 1; end if;
        return dps * US_SPAN / 180 / 50;
    end function;
    constant SERVO_STEP : integer := calc_step(SERVO_SPEED_DPS);

    signal blink_cnt : unsigned(24 downto 0) := (others => '0');
    signal blink     : std_logic;
    signal dim       : std_logic;
begin
    -- ---------- Latch servos x3 ----------
    g_servo : for i in 0 to 2 generate
        signal pw : unsigned(11 downto 0);
    begin
        pw <= to_unsigned(UNLOCK_US, 12) when unlock(i) = '1'
              else to_unsigned(LOCK_US, 12);
        u_sv : entity work.io_servo
            generic map (CLK_HZ => CLK_HZ, STEP_US => SERVO_STEP)
            port map (clk => clk, rst => rst, pulse_us => pw, pwm => servo(i));
    end generate;

    -- ---------- Slot LEDs ----------
    process (clk)
    begin
        if rising_edge(clk) then
            blink_cnt <= blink_cnt + 1;
        end if;
    end process;
    blink <= blink_cnt(24);
    dim   <= '1' when blink_cnt(15 downto 13) = "000" else '0';

    g_led : for i in 0 to 2 generate
        slot_led(i) <= '1'   when unlock(i) = '1' else                             -- released
                       blink when state = ST_ITEM and to_integer(slot) = i else   -- choosing
                       dim   when occ(i) = '1' else                               -- holds an item
                       '0';                                                        -- empty
    end generate;
end architecture;
