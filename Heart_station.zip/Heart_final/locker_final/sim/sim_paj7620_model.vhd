-- ============================================================
-- sim_paj7620_model.vhd  Simulated PAJ7620 sensor (simulation only)
--
-- Acts as I2C slave 0x73 : returns Part ID 0x20 at register 0x00,
-- accepts register writes (counted in n_writes) and returns the gesture value
-- from port gesture when register 0x43 is read (a repeated value reads as 0, like the real sensor)
-- powered = false simulates a loose VCC wire: no ACK, and every register written
-- during init is lost (gestures are only reported again after a full re-init)
-- hang  : rising edge -> the sensor holds SDA low (stuck in the middle of a byte)
--         until it sees 9 SCL clocks (an I2C bus clear), then lets go
-- wipe  : while true, the next access makes the sensor forget its 220 settings
--         but it still answers I2C and the Part ID (gesture engine stopped)
-- Used by tb_board1, tb_sensor and tb_system
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity sim_paj7620_model is
    port (
        scl      : inout std_logic;
        sda      : inout std_logic;
        gesture  : in    std_logic_vector(7 downto 0);   -- value returned when 0x43 is read
        n_writes : out   integer;                         -- number of register writes received
        powered  : in    boolean := true;                 -- false = sensor has no power
        hang     : in    boolean := false;                -- rising edge: hold SDA low
        wipe     : in    boolean := false                 -- true: forget settings, keep answering
    );
end entity;

architecture sim of sim_paj7620_model is
    constant ADDR : std_logic_vector(6 downto 0) := "1110011";
    signal stuck : boolean := false;
begin
    scl <= 'Z';

    -- second driver on SDA: stuck low until 9 SCL rising edges are seen
    sda <= '0' when stuck else 'Z';
    process
    begin
        wait until hang;
        stuck <= true;
        for i in 1 to 9 loop
            wait until to_X01(scl) = '0';
            wait until to_X01(scl) = '1';
        end loop;
        stuck <= false;
        wait until not hang;
    end process;

    process
        type mem_t is array (0 to 255) of std_logic_vector(7 downto 0);
        variable mem    : mem_t := (others => x"00");
        variable addr_b, b : std_logic_vector(7 downto 0);
        variable ptr    : integer := 0;
        variable bank   : integer := 0;          -- register bank selected by 0xEF
        variable stop   : boolean;
        variable writes : integer := 0;
        variable gest_q, gest_l : std_logic_vector(7 downto 0) := x"00";

        procedure get_byte(d : out std_logic_vector(7 downto 0); st : out boolean) is
            variable v : std_logic_vector(7 downto 0);
        begin
            st := false;
            for i in 7 downto 0 loop
                wait until to_X01(scl) = '1';
                v(i) := to_X01(sda);
                wait until to_X01(scl) = '0' or to_X01(sda) /= v(i);
                if to_X01(scl) = '1' then        -- SDA changed while SCL high = STOP/START
                    st := true;
                    return;
                end if;
            end loop;
            d := v;
        end procedure;

        procedure ack is
        begin
            sda <= '0';
            wait until to_X01(scl) = '1';
            wait until to_X01(scl) = '0';
            sda <= 'Z';
        end procedure;

        procedure put_byte(d : std_logic_vector(7 downto 0)) is
        begin
            for i in 7 downto 0 loop
                if d(i) = '0' then sda <= '0'; else sda <= 'Z'; end if;
                wait until to_X01(scl) = '1';
                wait until to_X01(scl) = '0';
            end loop;
            sda <= 'Z';
            wait until to_X01(scl) = '1';        -- master sends NACK
            wait until to_X01(scl) = '0';
        end procedure;
    begin
        sda      <= 'Z';
        n_writes <= 0;
        mem(0)   := x"20";                       -- Part ID low byte
        loop
            wait until to_X01(sda) = '0' and to_X01(scl) = '1';   -- START
            get_byte(addr_b, stop);
            next when stop;
            next when addr_b(7 downto 1) /= ADDR;
            if wipe then                         -- engine stopped: settings lost, still ACKs
                writes   := 0;
                n_writes <= 0;
            end if;
            if not powered then                  -- no power: no ACK, settings lost
                writes   := 0;
                n_writes <= 0;
                mem      := (others => x"00");   -- back to power-on values
                bank     := 0;
                mem(0)   := x"20";
                next;
            end if;
            ack;
            if addr_b(0) = '0' then              -- master writes
                get_byte(b, stop);
                next when stop;
                ack;
                ptr := to_integer(unsigned(b));
                loop
                    get_byte(b, stop);
                    exit when stop;
                    ack;
                    if ptr = 16#EF# then
                        bank := to_integer(unsigned(b));
                    elsif bank = 0 then
                        mem(ptr) := b;               -- only Bank 0 is modelled
                    end if;
                    mem(0)   := x"20";               -- Part ID is read-only
                    writes   := writes + 1;
                    n_writes <= writes;
                end loop;
            else                                 -- master reads
                if ptr = 16#43# then
                    gest_q := gesture;
                    if writes < 220 then gest_q := x"00"; end if;          -- not initialized
                    if gest_q = gest_l then gest_q := x"00"; end if;   -- cleared after read
                    gest_l := gesture;
                    put_byte(gest_q);
                else
                    put_byte(mem(ptr));
                end if;
            end if;
        end loop;
    end process;
end architecture;
