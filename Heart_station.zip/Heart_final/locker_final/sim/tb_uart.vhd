-- ============================================================
-- tb_uart.vhd  Testbench: bus_uart_tx -> wire -> bus_uart_rx  (50 MHz, 115200 baud)
--
--   * all 256 byte values arrive unchanged
--   * bit time on the wire is 434 clocks (8.68 us)
--   * a short noise spike on the idle line is not taken as a byte
--   * a frame with a bad stop bit is dropped (ferr pulse, no valid)
--   * the receiver works with a transmitter that is 2 % slower (other board's clock)
--
-- In Vivado: Simulation Sources = this file (bus_uart_tx / bus_uart_rx from the design)
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_uart is
end entity;

architecture sim of tb_uart is
    constant CLK_HZ : integer := 50_000_000;
    constant BIT_NS : time := 8680 ns;           -- 1 / 115200

    signal clk      : std_logic := '0';
    signal rst      : std_logic := '1';
    signal finished : boolean := false;

    signal send, busy, done : std_logic := '0';
    signal tx_data  : std_logic_vector(7 downto 0) := x"00";
    signal tx_line  : std_logic;
    signal manual   : std_logic := '1';           -- line driven by the testbench
    signal use_man  : boolean := false;
    signal line     : std_logic;

    signal rx_data  : std_logic_vector(7 downto 0);
    signal valid, ferr : std_logic;
    signal n_valid, n_ferr : integer := 0;
    signal last     : std_logic_vector(7 downto 0) := x"00";
begin
    clk <= not clk after 10 ns when not finished else '0';
    line <= manual when use_man else tx_line;

    u_tx : entity work.bus_uart_tx
        generic map (CLK_HZ => CLK_HZ, BAUD => 115_200)
        port map (clk => clk, rst => rst, send => send, data => tx_data,
                  tx => tx_line, busy => busy, done => done);

    u_rx : entity work.bus_uart_rx
        generic map (CLK_HZ => CLK_HZ, BAUD => 115_200)
        port map (clk => clk, rst => rst, rx => line,
                  data => rx_data, valid => valid, ferr => ferr);

    process (clk)
    begin
        if rising_edge(clk) then
            if valid = '1' then n_valid <= n_valid + 1; last <= rx_data; end if;
            if ferr  = '1' then n_ferr  <= n_ferr + 1; end if;
        end if;
    end process;

    stim : process
        variable errors : integer := 0;
        variable bad    : integer := 0;
        variable t0     : time;
        variable n0     : integer;

        procedure check(cond : boolean; name : string) is
        begin
            if cond then report "PASS : " & name severity note;
            else report "FAIL : " & name severity error; errors := errors + 1;
            end if;
        end procedure;

        -- send one frame by hand with a chosen bit time and stop bit
        procedure frame(b : std_logic_vector(7 downto 0); t : time; stop : std_logic) is
        begin
            manual <= '0'; wait for t;
            for i in 0 to 7 loop manual <= b(i); wait for t; end loop;
            manual <= stop; wait for t;
            manual <= '1'; wait for 3 * t;
        end procedure;
    begin
        wait for 100 ns;
        wait until rising_edge(clk);
        rst <= '0';
        wait for 1 us;

        -- all byte values
        for v in 0 to 255 loop
            wait until rising_edge(clk);
            tx_data <= std_logic_vector(to_unsigned(v, 8));
            send <= '1';
            wait until rising_edge(clk);
            send <= '0';
            wait until rising_edge(clk) and done = '1';
            wait for 2 * BIT_NS;
            if last /= std_logic_vector(to_unsigned(v, 8)) then bad := bad + 1; end if;
        end loop;
        check(n_valid = 256 and bad = 0 and n_ferr = 0,
              "256 bytes received unchanged (" & integer'image(n_valid) & " ok, " &
              integer'image(bad) & " wrong)");

        -- bit time on the wire
        wait until rising_edge(clk);
        tx_data <= x"55"; send <= '1';
        wait until rising_edge(clk); send <= '0';
        wait until tx_line = '0'; t0 := now;
        wait until tx_line = '1';
        check(now - t0 = 434 * 20 ns, "start bit = 434 clocks (" & time'image(now - t0) & ")");
        wait until rising_edge(clk) and done = '1';
        wait for 2 * BIT_NS;

        -- noise spike on the idle line
        use_man <= true;
        n0 := n_valid;
        manual <= '0'; wait for 1 us; manual <= '1';
        wait for 20 * BIT_NS;
        check(n_valid = n0, "1 us spike is ignored");

        -- bad stop bit
        n0 := n_valid;
        frame(x"4E", BIT_NS, '0');
        wait for 5 * BIT_NS;
        check(n_valid = n0 and n_ferr = 1, "frame with stop bit 0 is dropped (ferr)");

        -- transmitter 2 % slow
        n0 := n_valid;
        frame(x"43", BIT_NS * 102 / 100, '1');
        wait for 2 * BIT_NS;
        check(n_valid = n0 + 1 and last = x"43", "byte from a 2 % slow sender received");

        if errors = 0 then report "===== ALL TESTS PASSED =====" severity note;
        else report "===== " & integer'image(errors) & " TEST(S) FAILED =====" severity error;
        end if;
        finished <= true;
        wait;
    end process;
end architecture;
