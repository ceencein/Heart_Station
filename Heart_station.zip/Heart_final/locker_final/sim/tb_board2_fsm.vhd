-- ============================================================
-- tb_board2_fsm.vhd  Testbench : UART bytes -> bus_uart_rx -> ctrl_fsm -> ctrl_text
--
-- Checks the 5-state flow  IDLE -> ROLE -> ITEM -> PROCESS -> DONE -> IDLE
-- and the slot occupancy memory:
--   * all slots start empty; receiver cannot start ("NO ITEMS YET")
--   * giver puts items: slot becomes full, IDLE shows ITEMS:n/3
--   * giver only sees empty slots, receiver only sees full slots (others skipped)
--   * all full: giver cannot start ("ALL SLOTS FULL")
--   * receiver takes an item: slot becomes empty
--   * CANCEL in PROCESS locks without changing occupancy ("CANCELLED")
--   * only the chosen slot is unlocked, NEXT / PREV ignored while unlocked, no auto-lock
--   * DONE ignores every command and returns to IDLE
--   * CANCEL in ITEM -> ROLE, CANCEL in ROLE -> IDLE, timeouts -> IDLE
--
-- CLK_HZ = 10_000 and BAUD = 1_000 to shorten the simulation (1 s = 10,000 clocks), IDLE_S = 2 s.
-- In Vivado: Simulation Sources = this file only (board 2 design files are used)
-- set as Top -> Run Behavioral Simulation -> Run All, read PASS / FAIL in the Tcl Console.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity tb_board2_fsm is
end entity;

architecture sim of tb_board2_fsm is
    constant SIM_HZ : integer := 10_000;

    signal clk : std_logic := '0';
    signal rst : std_logic := '1';
    signal finished : boolean := false;

    -- UART wire (driven by a transmitter like board 1)
    signal t_send     : std_logic := '0';
    signal t_byte     : std_logic_vector(7 downto 0) := x"00";
    signal t_busy, t_done, line : std_logic;
    signal rx_data    : std_logic_vector(7 downto 0);
    signal rx_valid, rx_ferr : std_logic;
    signal rx_cmd     : std_logic_vector(2 downto 0);

    -- board 2
    signal c_next, c_prev, c_confirm, c_cancel : std_logic;
    signal state      : unsigned(2 downto 0);
    signal role       : std_logic;
    signal slot       : unsigned(1 downto 0);
    signal unlock     : std_logic_vector(2 downto 0);
    signal occ        : std_logic_vector(2 downto 0);
    signal done_ok    : std_logic;
    signal line1, line2 : lcd_line_t;
    signal s3, s2, s1, s0 : unsigned(3 downto 0);
begin
    clk <= not clk after 50 us when not finished else '0';

    u_txb1 : entity work.bus_uart_tx                  -- plays board 1
        generic map (CLK_HZ => SIM_HZ, BAUD => 1_000)
        port map (clk => clk, rst => rst, send => t_send, data => t_byte,
                  tx => line, busy => t_busy, done => t_done);

    u_rx : entity work.bus_uart_rx                    -- board 2 receiver
        generic map (CLK_HZ => SIM_HZ, BAUD => 1_000)
        port map (clk => clk, rst => rst, rx => line,
                  data => rx_data, valid => rx_valid, ferr => rx_ferr);

    rx_cmd    <= byte2cmd(rx_data);
    c_next    <= '1' when rx_valid = '1' and rx_cmd = CMD_NEXT    else '0';
    c_prev    <= '1' when rx_valid = '1' and rx_cmd = CMD_PREV    else '0';
    c_confirm <= '1' when rx_valid = '1' and rx_cmd = CMD_CONFIRM else '0';
    c_cancel  <= '1' when rx_valid = '1' and rx_cmd = CMD_CANCEL  else '0';

    u_fsm : entity work.ctrl_fsm
        generic map (CLK_HZ => SIM_HZ, IDLE_S => 2, DONE_MS => 3_000)
        port map (clk => clk, rst => rst,
                  c_next => c_next, c_prev => c_prev, c_confirm => c_confirm, c_cancel => c_cancel,
                  state => state, role => role, slot => slot, unlock => unlock,
                  occ => occ, done_ok => done_ok);

    u_txt : entity work.ctrl_text
        port map (state => state, role => role, slot => slot, occ => occ, done_ok => done_ok,
                  line1 => line1, line2 => line2,
                  sym3 => s3, sym2 => s2, sym1 => s1, sym0 => s0);

    stim : process
        variable errors : integer := 0;

        procedure tick(n : integer) is
        begin
            for i in 1 to n loop wait until rising_edge(clk); end loop;
        end procedure;

        -- one command as one UART byte ('N', 'P', 'C', 'X')
        procedure send_cmd(c : std_logic_vector(2 downto 0)) is
        begin
            wait until rising_edge(clk);
            t_byte <= cmd2byte(c); t_send <= '1';
            wait until rising_edge(clk);
            t_send <= '0';
            wait until rising_edge(clk) and t_done = '1';
            tick(20);
        end procedure;

        procedure check(cond : boolean; name : string) is
        begin
            if cond then report "PASS : " & name severity note;
            else report "FAIL : " & name severity error; errors := errors + 1;
            end if;
        end procedure;

        function to_str(l : lcd_line_t) return string is
            variable r : string(1 to 16);
        begin
            for i in 0 to 15 loop
                r(i + 1) := character'val(to_integer(unsigned(l(8 * (15 - i) + 7 downto 8 * (15 - i)))));
            end loop;
            return r;
        end function;

        procedure check_lcd(a, b : string; name : string) is
        begin
            check(to_str(line1) = a and to_str(line2) = b,
                  name & "  [" & to_str(line1) & "|" & to_str(line2) & "]");
        end procedure;

        function bits(v : std_logic_vector(2 downto 0)) return string is
            variable r : string(1 to 3);
        begin
            for i in 0 to 2 loop
                if v(2 - i) = '1' then r(i + 1) := '1'; else r(i + 1) := '0'; end if;
            end loop;
            return r;
        end function;

        procedure wait_idle is
        begin
            while state /= ST_IDLE loop wait until rising_edge(clk); end loop;
        end procedure;

        -- whole giver / receiver transaction: start, pick role, skip n_next slots, confirm
        procedure transaction(receiver : boolean; n_next : integer) is
        begin
            send_cmd(CMD_NEXT);                          -- IDLE -> ROLE (giver)
            if receiver then send_cmd(CMD_NEXT); end if; -- receiver
            send_cmd(CMD_CONFIRM);                       -- -> ITEM
            for i in 1 to n_next loop send_cmd(CMD_NEXT); end loop;
            send_cmd(CMD_CONFIRM);                       -- -> PROCESS
            send_cmd(CMD_CONFIRM);                       -- -> DONE (confirmed)
            wait_idle;
        end procedure;
    begin
        tick(10);
        rst <= '0';
        tick(10);

        -- ===== start: everything empty =====
        check(state = ST_IDLE and unlock = "000" and occ = "000", "start: IDLE, locked, all empty");
        check_lcd(" Drop and Pick !", "SWIPE  ITEMS:0/3", "LCD IDLE 0/3");
        send_cmd(CMD_CANCEL);
        check(state = ST_IDLE, "CANCEL in IDLE does nothing");

        -- ===== receiver with no items =====
        send_cmd(CMD_NEXT);
        check(state = ST_ROLE and role = ROLE_GIVER, "swipe -> ROLE, giver first");
        check(s3 = 1 and s2 = SYM_G, "7-seg '1 G'");
        send_cmd(CMD_NEXT);
        check(role = ROLE_RECEIVER, "NEXT -> receiver");
        check_lcd("ROLE: RECEIVER  ", "NO ITEMS YET    ", "LCD receiver, nothing to take");
        send_cmd(CMD_CONFIRM);
        check(state = ST_ROLE, "receiver cannot continue when all slots are empty");
        send_cmd(CMD_PREV);
        check(role = ROLE_GIVER, "PREV -> giver");
        check_lcd("ROLE: GIVER     ", "<SWIPE> CW=OK   ", "LCD ROLE giver");

        -- ===== giver puts an item in slot 2 =====
        send_cmd(CMD_CONFIRM);
        check(state = ST_ITEM and slot = 0 and unlock = "000", "giver -> ITEM, starts on slot 1");
        check_lcd("SELECT SLOT: 1  ", "<SWIPE> CW=OPEN ", "LCD ITEM");
        send_cmd(CMD_NEXT);
        check(slot = 1, "NEXT -> slot 2");
        send_cmd(CMD_CONFIRM);
        check(state = ST_PROCESS and unlock = "010", "CONFIRM -> unlock slot 2 only");
        check_lcd("SLOT 2 UNLOCKED ", "PUT ITEM, CW=OK ", "LCD PROCESS giver");
        send_cmd(CMD_NEXT); send_cmd(CMD_PREV);
        check(state = ST_PROCESS and unlock = "010" and slot = 1, "NEXT / PREV ignored while unlocked");
        tick(60 * SIM_HZ);
        check(state = ST_PROCESS and unlock = "010", "stays unlocked after 60 s (no auto-lock)");
        send_cmd(CMD_CONFIRM);
        check(state = ST_DONE and unlock = "000" and occ = "010", "CONFIRM -> DONE, slot 2 now full");
        check_lcd("SLOT 2 LOCKED   ", "THANK YOU GIVER!", "LCD DONE giver");
        send_cmd(CMD_NEXT); send_cmd(CMD_CONFIRM);
        check(state = ST_DONE and unlock = "000", "commands ignored in DONE");
        wait_idle;
        check_lcd(" Drop and Pick !", "SWIPE  ITEMS:1/3", "LCD IDLE 1/3");

        -- ===== giver skips the full slot 2 =====
        send_cmd(CMD_NEXT); send_cmd(CMD_CONFIRM);   -- giver -> ITEM
        check(slot = 0, "giver starts on empty slot 1");
        send_cmd(CMD_NEXT);
        check(slot = 2, "giver NEXT skips full slot 2 -> slot 3");
        send_cmd(CMD_NEXT);
        check(slot = 0, "NEXT wraps 3 -> 1");
        send_cmd(CMD_PREV);
        check(slot = 2, "PREV wraps 1 -> 3 (skips 2)");

        -- CANCEL in PROCESS: lock, nothing changes
        send_cmd(CMD_CONFIRM);
        check(state = ST_PROCESS and unlock = "100", "slot 3 unlocked");
        send_cmd(CMD_CANCEL);
        check(state = ST_DONE and unlock = "000" and occ = "010", "CANCEL locks, occupancy unchanged");
        check_lcd("SLOT 3 LOCKED   ", "CANCELLED       ", "LCD DONE cancelled");
        wait_idle;

        -- ===== fill slots 1 and 3 -> all full =====
        transaction(false, 0);                       -- slot 1
        check(occ = "011", "slot 1 full (occ " & bits(occ) & ")");
        transaction(false, 0);                       -- first empty is now slot 3
        check(occ = "111", "slot 3 full, all full (occ " & bits(occ) & ")");
        check_lcd(" Drop and Pick !", "SWIPE  ITEMS:3/3", "LCD IDLE 3/3");

        send_cmd(CMD_NEXT);                          -- ROLE giver
        check_lcd("ROLE: GIVER     ", "ALL SLOTS FULL  ", "LCD giver, no empty slot");
        send_cmd(CMD_CONFIRM);
        check(state = ST_ROLE, "giver cannot continue when all slots are full");

        -- ===== receiver takes from slot 2 =====
        send_cmd(CMD_NEXT);                          -- receiver
        send_cmd(CMD_CONFIRM);
        check(state = ST_ITEM and slot = 0, "receiver starts on full slot 1");
        send_cmd(CMD_NEXT);
        check(slot = 1, "receiver NEXT -> slot 2");
        send_cmd(CMD_CONFIRM);
        check_lcd("SLOT 2 UNLOCKED ", "TAKE ITEM,CW=OK ", "LCD PROCESS receiver");
        send_cmd(CMD_CONFIRM);
        check(occ = "101", "slot 2 empty again (occ " & bits(occ) & ")");
        check_lcd("SLOT 2 LOCKED   ", "HAVE A NICE DAY ", "LCD DONE receiver");
        wait_idle;

        -- receiver now skips empty slot 2
        send_cmd(CMD_NEXT); send_cmd(CMD_NEXT); send_cmd(CMD_CONFIRM);
        send_cmd(CMD_NEXT);
        check(slot = 2, "receiver NEXT skips empty slot 2 -> slot 3");

        -- ===== going back / timeouts =====
        send_cmd(CMD_CANCEL);
        check(state = ST_ROLE and unlock = "000", "CANCEL in ITEM -> back to ROLE");
        send_cmd(CMD_CANCEL);
        check(state = ST_IDLE and unlock = "000", "CANCEL in ROLE -> IDLE");
        send_cmd(CMD_NEXT);
        tick(2 * SIM_HZ + 50);
        check(state = ST_IDLE, "no gesture 2 s in ROLE -> IDLE");
        send_cmd(CMD_NEXT); send_cmd(CMD_CONFIRM);
        tick(2 * SIM_HZ + 50);
        check(state = ST_IDLE and unlock = "000", "no gesture 2 s in ITEM -> IDLE");
        check(occ = "101", "timeouts do not change occupancy");

        if errors = 0 then
            report "===== ALL TESTS PASSED =====" severity note;
        else
            report "===== " & integer'image(errors) & " TEST(S) FAILED =====" severity error;
        end if;
        finished <= true;
        wait;
    end process;
end architecture;
