-- ============================================================
-- tb_board1.vhd  Testbench: board 1 alone (UART out, watchdog, no-answer detection)
--
--   * board left alone for longer than WDT_S -> the whole board resets itself
--     (seen as a new full sensor init: +220 register writes) and works again
--   * while gestures keep coming, the watchdog never fires
--
-- WDT_S = 2 s and CLK_HZ = 2 MHz to shorten the simulation (real default 120 s).
-- In Vivado: Simulation Sources = this file + sim/sim_paj7620_model.vhd
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_board1 is
end entity;

architecture sim of tb_board1 is
    constant SIM_HZ : integer := 2_000_000;

    signal clk      : std_logic := '0';
    signal finished : boolean := false;

    signal pb       : std_logic_vector(4 downto 0) := (others => '0');
    signal led      : std_logic_vector(7 downto 0);
    signal digit    : std_logic_vector(3 downto 0);
    signal seg      : std_logic_vector(7 downto 0);
    signal buzz     : std_logic;
    signal scl, sda : std_logic;
    signal w_tx     : std_logic;                   -- board 1 uart_tx
    signal r_data   : std_logic_vector(7 downto 0);
    signal r_valid, r_ferr : std_logic;
    signal last_byte : std_logic_vector(7 downto 0) := x"00";
    signal gesture  : std_logic_vector(7 downto 0) := x"00";
    signal n_writes : integer;
    signal n_bytes  : integer := 0;
begin
    clk <= not clk after 250 ns when not finished else '0';
    scl <= 'H'; sda <= 'H';

    dut : entity work.board1
        generic map (CLK_HZ => SIM_HZ, WDT_S => 2)
        port map (clk => clk, pb => pb, led => led, digit => digit, Seven_Segment => seg,
                  Buzzer => buzz, paj_scl => scl, paj_sda => sda,
                  uart_tx => w_tx, uart_rx => '1');      -- no board 2: nobody answers

    m_paj : entity work.sim_paj7620_model
        port map (scl => scl, sda => sda, gesture => gesture, n_writes => n_writes);

    -- decode what board 1 sends
    u_mon : entity work.bus_uart_rx
        generic map (CLK_HZ => SIM_HZ, BAUD => 115_200)
        port map (clk => clk, rst => '0', rx => w_tx, data => r_data, valid => r_valid, ferr => r_ferr);

    process (clk)
    begin
        if rising_edge(clk) then
            if r_valid = '1' then n_bytes <= n_bytes + 1; last_byte <= r_data; end if;
        end if;
    end process;

    stim : process
        variable errors : integer := 0;
        variable w0, s0 : integer;

        procedure check(cond : boolean; name : string) is
        begin
            if cond then report "PASS : " & name severity note;
            else report "FAIL : " & name severity error; errors := errors + 1;
            end if;
        end procedure;

        procedure do_gesture(g : std_logic_vector(7 downto 0)) is
        begin
            gesture <= g; wait for 60 ms;
            gesture <= x"00"; wait for 300 ms;
        end procedure;
    begin
        wait for 700 ms;
        check(n_writes = 220 and led(4) = '1', "first init done, sensor ready");

        -- in use: a gesture every ~0.8 s for 4 s -> no reset
        w0 := n_writes;
        for i in 1 to 5 loop
            do_gesture(x"08");
            wait for 440 ms;
        end loop;
        check(n_writes = w0, "no watchdog reset while gestures keep coming (writes " &
              integer'image(n_writes) & ")");

        -- left alone 2.5 s -> watchdog resets the board, sensor set up again
        wait for 2500 ms;
        check(n_writes >= w0 + 220, "watchdog reset after 2 s idle -> sensor re-init (writes " &
              integer'image(n_writes) & ")");
        check(led(4) = '1' and led(5) = '0', "sensor ready again after the auto reset");

        -- still works after the auto reset
        s0 := n_bytes;
        do_gesture(x"40");
        check(n_bytes = s0 + 1 and last_byte = x"43" and led(2) = '1',
              "gesture after auto reset -> 'C' (CONFIRM) sent on uart_tx");
        check(led(6) = '0' and led(7) = '1',
              "no board 2: link LED off, 'no answer' LED on");

        if errors = 0 then report "===== ALL TESTS PASSED =====" severity note;
        else report "===== " & integer'image(errors) & " TEST(S) FAILED =====" severity error;
        end if;
        finished <= true;
        wait;
    end process;
end architecture;
