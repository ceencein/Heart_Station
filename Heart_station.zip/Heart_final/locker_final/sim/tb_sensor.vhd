-- ============================================================
-- tb_sensor.vhd  Testbench: sensor_paj7620 recovers after the sensor loses power
--
-- Reproduces "sensor moved / wire loose -> stops working":
--   1) normal init, a gesture is received
--   2) sensor power off for 300 ms (no ACK, settings lost)
--      -> sensor_err must go '1' and init_done must drop to '0'
--   3) power back on -> the controller must wake the sensor and send all
--      220 init pairs again by itself (no reset button), then gestures work
--   4) SDA stuck low (no I2C error, reads look like 0x00): the Part ID health
--      check must notice, clear the bus with 9 clocks and re-init
--   5) settings lost while I2C still answers (gesture engine stopped):
--      the idle re-init must refresh the sensor after IDLE_REINIT_S
-- Test generics: CHECK_MS = 200 ms, IDLE_REINIT_S = 2 s (real defaults 1000 ms / 60 s)
--
-- CLK_HZ = 2_000_000 to shorten the simulation.
-- In Vivado add this file + sim/sim_paj7620_model.vhd as Simulation Sources.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity tb_sensor is
end entity;

architecture sim of tb_sensor is
    constant SIM_HZ : integer := 2_000_000;

    signal clk      : std_logic := '0';
    signal rst      : std_logic := '1';
    signal finished : boolean := false;

    signal scl, sda    : std_logic;
    signal scl_o, sda_o : std_logic;
    signal gesture     : std_logic_vector(7 downto 0) := x"00";
    signal n_writes    : integer;
    signal powered     : boolean := true;
    signal hang, wipe  : boolean := false;
    signal recover     : std_logic;
    signal n_recover   : integer := 0;

    signal gest_valid, raw_valid, init_done, sensor_err : std_logic;
    signal gest_cmd : std_logic_vector(2 downto 0);
    signal gest_raw : std_logic_vector(7 downto 0);

    signal n_valid  : integer := 0;
    signal last_cmd : std_logic_vector(2 downto 0) := CMD_NONE;
    signal err_seen : boolean := false;
begin
    clk <= not clk after 250 ns when not finished else '0';

    scl <= 'H'; sda <= 'H';                                -- I2C pull-ups
    scl <= 'Z' when scl_o = '1' else '0';
    sda <= 'Z' when sda_o = '1' else '0';

    dut : entity work.sensor_paj7620
        generic map (CLK_HZ => SIM_HZ, CHECK_MS => 200, IDLE_REINIT_S => 2)
        port map (clk => clk, rst => rst, recover => recover,
                  gest_valid => gest_valid, gest_cmd => gest_cmd, gest_raw => gest_raw,
                  raw_valid => raw_valid, init_done => init_done, sensor_err => sensor_err,
                  scl_o => scl_o, sda_o => sda_o, sda_i => sda);

    m_paj : entity work.sim_paj7620_model
        port map (scl => scl, sda => sda, gesture => gesture,
                  n_writes => n_writes, powered => powered, hang => hang, wipe => wipe);

    process (clk)
    begin
        if rising_edge(clk) then
            if gest_valid = '1' then
                n_valid  <= n_valid + 1;
                last_cmd <= gest_cmd;
            end if;
            if sensor_err = '1' then err_seen <= true; end if;
            if recover = '1' then n_recover <= n_recover + 1; end if;
        end if;
    end process;

    stim : process
        variable errors : integer := 0;
        variable n0, r0 : integer;

        procedure check(cond : boolean; name : string) is
        begin
            if cond then report "PASS : " & name severity note;
            else report "FAIL : " & name severity error; errors := errors + 1;
            end if;
        end procedure;

        procedure do_gesture(g : std_logic_vector(7 downto 0)) is
        begin
            gesture <= g; wait for 60 ms;
            gesture <= x"00"; wait for 300 ms;
        end procedure;
    begin
        wait for 10 us;
        rst <= '0';
        wait until init_done = '1' for 2000 ms;
        check(init_done = '1' and n_writes = 220, "first init done (220 writes)");

        n0 := n_valid;
        do_gesture(x"08");
        check(n_valid = n0 + 1 and last_cmd = CMD_NEXT, "gesture before power loss -> NEXT");

        -- sensor loses power
        powered <= false;
        wait for 300 ms;
        check(err_seen, "sensor_err raised while sensor has no power");
        check(init_done = '0', "init_done dropped -> controller restarted");

        -- power back: must recover by itself
        powered <= true;
        wait until init_done = '1' for 3000 ms;
        check(init_done = '1' and n_writes = 220, "re-init after power returns (220 writes)");
        wait for 50 ms;
        check(sensor_err = '0', "sensor_err cleared");

        n0 := n_valid;
        do_gesture(x"40");
        check(n_valid = n0 + 1 and last_cmd = CMD_CONFIRM, "gesture after recovery -> CONFIRM");

        -- SDA stuck low
        r0 := n_recover;
        hang <= true;
        wait for 400 ms;                              -- > CHECK_MS
        hang <= false;
        check(n_recover > r0, "stuck SDA detected by Part ID check (recover pulse)");
        wait until init_done = '1' for 3000 ms;
        check(init_done = '1' and n_writes >= 220,
              "bus cleared and re-init after stuck SDA (writes " & integer'image(n_writes) &
              ", recoveries " & integer'image(n_recover - r0) & ")");
        n0 := n_valid;
        do_gesture(x"04");
        check(n_valid = n0 + 1 and last_cmd = CMD_PREV, "gesture after stuck SDA -> PREV");

        -- settings lost, sensor still answers
        wipe <= true; wait for 30 ms; wipe <= false;
        check(n_writes = 0, "sensor lost its settings (model)");
        n0 := n_valid;
        do_gesture(x"08");
        check(n_valid = n0, "no gesture while settings are lost");
        r0 := n_recover;
        wait for 2500 ms;                             -- > IDLE_REINIT_S
        check(n_recover > r0 and n_writes = 220, "idle re-init refreshed the sensor");
        n0 := n_valid;
        do_gesture(x"80");
        check(n_valid = n0 + 1 and last_cmd = CMD_CANCEL, "gesture after idle re-init -> CANCEL");

        if errors = 0 then report "===== ALL TESTS PASSED =====" severity note;
        else report "===== " & integer'image(errors) & " TEST(S) FAILED =====" severity error;
        end if;
        finished <= true;
        wait;
    end process;
end architecture;
