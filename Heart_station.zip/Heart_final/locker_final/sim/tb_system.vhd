-- ============================================================
-- tb_system.vhd  Testbench: the whole locker
--   sim_paj7620_model -> board1 <==UART, 2 signal wires==> board2
--
-- A full giver transaction done only with gestures:
--   swipe right (start) -> ROLE, clockwise -> ITEM, swipe right -> slot 2,
--   clockwise -> PROCESS (slot 2 unlocked), clockwise -> DONE (locked), wait -> IDLE
-- Checks the board 2 7-segment state digit, the slot LEDs (incl. dim = slot holds an
-- item after the giver confirmed), the servo of slot 2, and the two-way link:
--   'A' reply -> one beep on board 1 (long for CONFIRM), 'R' reply -> two beeps,
--   loose return wire -> link LED off and two beeps (no answer).
--
-- CLK_HZ = 2_000_000 on both boards to shorten the simulation.
-- Needs every file of board1/ and board2/ (pkg_locker, io_debounce, io_seg7 only once)
-- + sim/sim_paj7620_model.vhd
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_system is
end entity;

architecture sim of tb_system is
    constant SIM_HZ : integer := 2_000_000;

    signal clk      : std_logic := '0';
    signal finished : boolean := false;

    -- board 1
    signal pb1      : std_logic_vector(4 downto 0) := (others => '0');
    signal led1     : std_logic_vector(7 downto 0);
    signal dig1     : std_logic_vector(3 downto 0);
    signal seg1     : std_logic_vector(7 downto 0);
    signal buzz     : std_logic;
    signal scl, sda : std_logic;
    signal gesture  : std_logic_vector(7 downto 0) := x"00";
    signal n_writes : integer;

    -- UART wires: board 1 pin5 -> board 2 pin5, board 2 pin6 -> board 1 pin6
    signal w_12     : std_logic;                    -- board 1 TX -> board 2 RX
    signal w_21     : std_logic;                    -- board 2 TX -> board 1 RX
    signal cut      : boolean := false;             -- simulate a loose return wire
    signal b1_rx    : std_logic;

    -- buzzer of board 1: count beeps and remember the length of the last one
    signal n_beep   : integer := 0;
    signal last_len : time := 0 ns;

    -- board 2
    signal pb2      : std_logic_vector(4 downto 0) := (others => '0');
    signal servo    : std_logic_vector(2 downto 0);
    signal sled     : std_logic_vector(2 downto 0);
    signal lcd_d    : std_logic_vector(7 downto 0);
    signal lcd_rs, lcd_e : std_logic;
    signal dig2     : std_logic_vector(3 downto 0);
    signal seg2     : std_logic_vector(7 downto 0);

    type seg4_t is array (3 downto 0) of std_logic_vector(7 downto 0);
    signal shown2 : seg4_t := (others => (others => '1'));

    function seg2int(s : std_logic_vector(7 downto 0)) return integer is
    begin
        case s is
            when "00000011" => return 0;
            when "10011111" => return 1;
            when "00100101" => return 2;
            when "00001101" => return 3;
            when "10011001" => return 4;
            when others     => return -1;
        end case;
    end function;
begin
    clk <= not clk after 250 ns when not finished else '0';
    scl <= 'H'; sda <= 'H';

    u_b1 : entity work.board1
        generic map (CLK_HZ => SIM_HZ, LINK_S => 1)
        port map (clk => clk, pb => pb1, led => led1, digit => dig1, Seven_Segment => seg1,
                  Buzzer => buzz, paj_scl => scl, paj_sda => sda,
                  uart_tx => w_12, uart_rx => b1_rx);

    b1_rx <= '1' when cut else w_21;                -- idle level when the wire is loose

    m_paj : entity work.sim_paj7620_model
        port map (scl => scl, sda => sda, gesture => gesture, n_writes => n_writes);

    u_b2 : entity work.board2
        generic map (CLK_HZ => SIM_HZ)
        port map (clk => clk, pb => pb2, uart_rx => w_12, uart_tx => w_21,
                  servo => servo, slot_led => sled, lcd_data => lcd_d, lcd_rs => lcd_rs,
                  lcd_e => lcd_e, digit => dig2, Seven_Segment => seg2);

    process (buzz)
        variable t_on : time := 0 ns;
    begin
        if rising_edge(buzz) then
            n_beep <= n_beep + 1; t_on := now;
        elsif falling_edge(buzz) then
            last_len <= now - t_on;
        end if;
    end process;

    -- capture the board 2 7-segment (digit(0) = left-most = state)
    process (clk)
    begin
        if rising_edge(clk) then
            for i in 0 to 3 loop
                if dig2(i) = '1' then shown2(3 - i) <= seg2; end if;
            end loop;
        end if;
    end process;

    stim : process
        variable errors : integer := 0;
        variable t0     : time;
        variable n_hi, n_other : integer;
        variable b0 : integer;

        procedure check(cond : boolean; name : string) is
        begin
            if cond then report "PASS : " & name severity note;
            else report "FAIL : " & name severity error; errors := errors + 1;
            end if;
        end procedure;

        procedure do_gesture(g : std_logic_vector(7 downto 0)) is
        begin
            gesture <= g; wait for 60 ms;
            gesture <= x"00"; wait for 300 ms;
            wait for 150 ms;                        -- > one 7-segment scan
        end procedure;

        procedure state_is(n : integer; name : string) is
        begin
            check(seg2int(shown2(3)) = n, name & " (board 2 shows state " &
                  integer'image(seg2int(shown2(3))) & ")");
        end procedure;
    begin
        wait for 800 ms;
        check(n_writes = 220 and led1(4) = '1', "board 1 sensor ready");
        state_is(0, "start in IDLE");

        b0 := n_beep;
        do_gesture(x"08"); state_is(1, "swipe right -> ROLE");
        check(n_beep = b0 + 1 and last_len = 200 ms and led1(7) = '0',
              "board 2 answered 'A' -> board 1 one short beep (" & time'image(last_len) & ")");
        check(led1(6) = '1', "board 1 link LED on (replies / heartbeat heard)");
        do_gesture(x"40"); state_is(2, "clockwise -> ITEM");
        do_gesture(x"08");
        check(seg2int(shown2(0)) = 2, "swipe right -> slot 2");
        check(sled = "000", "slot LEDs: chosen slot only blinks, nothing unlocked");
        b0 := n_beep;
        do_gesture(x"40"); state_is(3, "clockwise -> PROCESS");
        wait for 200 ms;
        check(n_beep = b0 + 1 and last_len = 500 ms, "CONFIRM accepted -> one long beep (" &
              time'image(last_len) & ")");
        check(sled = "010", "slot 2 LED on (unlocked)");

        -- servo 2 must be at the unlock angle (1925 us), the others at lock (975 us)
        wait for 600 ms;                            -- smooth move finishes
        wait until servo(1) = '1'; t0 := now; wait until servo(1) = '0';
        check(now - t0 = 1925 us, "servo 2 at unlock angle (" & time'image(now - t0) & ")");
        wait until servo(0) = '1'; t0 := now; wait until servo(0) = '0';
        check(now - t0 = 975 us, "servo 1 stays locked (" & time'image(now - t0) & ")");

        do_gesture(x"40"); state_is(4, "clockwise -> DONE");
        -- slot 2 now holds an item: its LED is dim (short pulses), the others are off
        n_hi := 0; n_other := 0;
        for i in 1 to 140000 loop                   -- 70 ms (dim period is 2^16 clocks)
            wait until rising_edge(clk);
            if sled(1) = '1' then n_hi := n_hi + 1; end if;
            if sled(0) = '1' or sled(2) = '1' then n_other := n_other + 1; end if;
        end loop;
        check(n_hi > 140000 / 20 and n_hi < 140000 / 4 and n_other = 0,
              "slot 2 LED dim = holds an item (" & integer'image(n_hi / 1400) & "% on), slots 1 and 3 off");
        b0 := n_beep;
        do_gesture(x"08"); state_is(4, "gesture ignored in DONE");
        check(n_beep = b0 + 2 and led1(7) = '1',
              "board 2 answered 'R' -> board 1 two short beeps, 'rejected' LED on");
        wait for 3000 ms;
        state_is(0, "DONE -> IDLE by itself");

        -- return wire comes loose: board 1 notices
        cut <= true;
        wait for 1500 ms;
        check(led1(6) = '0', "return wire loose -> board 1 link LED off after LINK_S");
        b0 := n_beep;
        do_gesture(x"08");
        check(n_beep = b0 + 2 and led1(7) = '1', "no answer -> two short beeps");
        state_is(1, "board 2 still got the command (one-way wire still connected)");
        cut <= false;
        wait for 1200 ms;                           -- next heartbeat
        check(led1(6) = '1', "wire back -> link LED on again");

        if errors = 0 then report "===== ALL TESTS PASSED =====" severity note;
        else report "===== " & integer'image(errors) & " TEST(S) FAILED =====" severity error;
        end if;
        finished <= true;
        wait;
    end process;
end architecture;
