-- ============================================================
-- tb_board2_servo.vhd  Testbench: board2 servo outputs
--
-- Presses the board 2 buttons: IDLE -> ROLE -> ITEM (slot 1) -> PROCESS -> DONE
-- and measures the pulse width of servo(0..2).
-- Expected with default generics (45 / 135 degrees, 180 deg/s):
--   IDLE    : 975 us on all servos
--   PROCESS : servo(0) moves smoothly to 1925 us, the other two stay at 975 us
--   DONE    : back to 975 us on all
-- CLK_HZ = 1_000_000 to shorten the simulation.
-- In Vivado: Set as Top -> Run Behavioral Simulation -> Run All, read PASS / FAIL.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_board2_servo is
end entity;

architecture sim of tb_board2_servo is
    constant HZ : integer := 1_000_000;

    signal clk      : std_logic := '0';
    signal finished : boolean := false;
    signal pb       : std_logic_vector(4 downto 0) := (others => '0');
    signal servo, sled : std_logic_vector(2 downto 0);
    signal ld       : std_logic_vector(7 downto 0);
    signal rs, e    : std_logic;
    signal dg       : std_logic_vector(3 downto 0);
    signal sg       : std_logic_vector(7 downto 0);
begin
    clk <= not clk after 500 ns when not finished else '0';

    dut : entity work.board2
        generic map (CLK_HZ => HZ)
        port map (clk => clk, pb => pb, uart_rx => '1', uart_tx => open, servo => servo,
                  slot_led => sled, lcd_data => ld, lcd_rs => rs, lcd_e => e,
                  digit => dg, Seven_Segment => sg);

    process
        variable errors     : integer := 0;
        variable t0         : time;
        variable w0, w1, w2 : time;

        procedure check(cond : boolean; name : string) is
        begin
            if cond then report "PASS : " & name severity note;
            else report "FAIL : " & name severity error; errors := errors + 1;
            end if;
        end procedure;

        procedure press(i : integer) is
        begin
            pb(i) <= '1'; wait for 30 ms; pb(i) <= '0'; wait for 30 ms;
        end procedure;

        procedure meas is
        begin
            wait until servo(0) = '1'; t0 := now; wait until servo(0) = '0'; w0 := now - t0;
            wait until servo(1) = '1'; t0 := now; wait until servo(1) = '0'; w1 := now - t0;
            wait until servo(2) = '1'; t0 := now; wait until servo(2) = '0'; w2 := now - t0;
        end procedure;

        function img(t : time) return string is
        begin
            return integer'image(t / 1 us) & " us";
        end function;
    begin
        wait for 1200 ms;                           -- power-on reset
        meas;
        check(w0 = 975 us and w1 = 975 us and w2 = 975 us,
              "IDLE: all locked at 45 deg (" & img(w0) & ", " & img(w1) & ", " & img(w2) & ")");

        press(3); press(0); press(0);               -- ROLE -> ITEM (slot 1) -> PROCESS
        wait for 50 ms;
        meas;
        check(w0 > 975 us and w0 < 1925 us, "PROCESS: servo 1 moving smoothly (" & img(w0) & ")");
        wait for 700 ms;
        meas;
        check(w0 = 1925 us, "PROCESS: servo 1 at unlock 135 deg (" & img(w0) & ")");
        check(w1 = 975 us and w2 = 975 us, "PROCESS: servos 2 and 3 stay locked");
        check(sled = "001", "slot 1 LED on");

        press(0);                                   -- -> DONE
        wait for 700 ms;
        meas;
        check(w0 = 975 us and w1 = 975 us and w2 = 975 us, "DONE: all locked again");

        if errors = 0 then report "===== ALL TESTS PASSED =====" severity note;
        else report "===== " & integer'image(errors) & " TEST(S) FAILED =====" severity error;
        end if;
        finished <= true;
        wait;
    end process;
end architecture;
