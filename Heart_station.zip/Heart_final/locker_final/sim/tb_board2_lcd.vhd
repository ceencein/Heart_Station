-- ============================================================
-- tb_board2_lcd.vhd  Testbench : ctrl_text -> io_lcd -> HD44780 model
--
-- LCD model: latches data on the falling edge of E and emulates clear /
-- set cursor / write character, and checks the HD44780 timing:
--   * E high for at least 450 ns
--   * RS / data stable while E is high
--   * at least 37 us between commands (1.52 ms after clear)
-- Then compares the simulated screen with the expected text of every state and role.
--
-- CLK_HZ = 1_000_000 to shorten the simulation (1 clock = 1 us)
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity tb_board2_lcd is
end entity;

architecture sim of tb_board2_lcd is
    constant SIM_HZ : integer := 1_000_000;

    signal clk      : std_logic := '0';
    signal rst      : std_logic := '1';
    signal finished : boolean := false;

    signal state : unsigned(2 downto 0) := "000";
    signal slot  : unsigned(1 downto 0) := "00";
    signal role  : std_logic := '0';
    signal occ   : std_logic_vector(2 downto 0) := "000";
    signal ok    : std_logic := '1';
    signal line1, line2 : lcd_line_t;
    signal s3, s2, s1, s0 : unsigned(3 downto 0);

    signal lcd_data : std_logic_vector(7 downto 0);
    signal lcd_rs, lcd_e : std_logic;

    signal screen     : string(1 to 32) := (others => ' ');
    signal timing_err : integer := 0;
begin
    clk <= not clk after 500 ns when not finished else '0';

    u_txt : entity work.ctrl_text
        port map (state => state, role => role, slot => slot, occ => occ, done_ok => ok, line1 => line1, line2 => line2,
                  sym3 => s3, sym2 => s2, sym1 => s1, sym0 => s0);

    u_lcd : entity work.io_lcd
        generic map (CLK_HZ => SIM_HZ)
        port map (clk => clk, rst => rst, line1 => line1, line2 => line2,
                  lcd_data => lcd_data, lcd_rs => lcd_rs, lcd_e => lcd_e);

    -- ---------------- HD44780 model ----------------
    model : process
        variable ddram    : string(1 to 32) := (others => ' ');
        variable cursor   : integer := 0;
        variable t_rise   : time := 0 ns;
        variable t_ready  : time := 0 ns;       -- when the LCD is ready for the next command
        variable d        : std_logic_vector(7 downto 0);
        variable rs       : std_logic;
        variable errs     : integer := 0;
    begin
        wait until rising_edge(lcd_e);
        t_rise := now;
        d  := lcd_data;
        rs := lcd_rs;
        if now < t_ready then
            report "TIMING: command sent before LCD finished previous one" severity error;
            errs := errs + 1;
        end if;
        wait until falling_edge(lcd_e) or lcd_data'event or lcd_rs'event;
        if lcd_e = '1' then
            report "TIMING: RS/data changed while E high" severity error;
            errs := errs + 1;
            wait until falling_edge(lcd_e);
        end if;
        if now - t_rise < 450 ns then
            report "TIMING: E pulse too short" severity error;
            errs := errs + 1;
        end if;

        -- latch on the falling edge of E
        if rs = '1' then
            if cursor < 32 then
                ddram(cursor + 1) := character'val(to_integer(unsigned(d)));
                cursor := cursor + 1;
            end if;
            t_ready := now + 37 us;
        elsif d(7) = '1' then                       -- set cursor
            if d(6) = '1' then cursor := 16 + to_integer(unsigned(d(3 downto 0)));
            else               cursor := to_integer(unsigned(d(3 downto 0)));
            end if;
            t_ready := now + 37 us;
        elsif d = x"01" then                        -- clear
            ddram  := (others => ' ');
            cursor := 0;
            t_ready := now + 1520 us;
        else
            t_ready := now + 37 us;                 -- other setup commands
        end if;
        screen     <= ddram;
        timing_err <= errs;
    end process;

    -- ---------------- Test sequence ----------------
    stim : process
        variable errors : integer := 0;

        procedure check(cond : boolean; name : string) is
        begin
            if cond then report "PASS : " & name severity note;
            else report "FAIL : " & name severity error; errors := errors + 1;
            end if;
        end procedure;

        procedure show(st : unsigned(2 downto 0); rl : std_logic; sl : unsigned(1 downto 0);
                       expect : string; name : string) is
        begin
            state <= st; role <= rl; slot <= sl;
            wait for 5 ms;                          -- the whole screen is rewritten every ~2 ms
            check(screen = expect, name & "  [" & screen & "]");
        end procedure;
    begin
        wait for 10 us;
        rst <= '0';
        wait for 70 ms;                             -- wait for LCD init (50 ms + setup)

        check(screen = " Drop and Pick !SWIPE  ITEMS:0/3", "LCD IDLE  [" & screen & "]");
        show(ST_ROLE,    '0', "00", "ROLE: GIVER     <SWIPE> CW=OK   ", "LCD ROLE giver");
        show(ST_ROLE,    '1', "00", "ROLE: RECEIVER  NO ITEMS YET    ", "LCD ROLE receiver (empty box)");
        show(ST_ITEM,    '1', "01", "SELECT SLOT: 2  <SWIPE> CW=OPEN ", "LCD ITEM");
        show(ST_PROCESS, '0', "10", "SLOT 3 UNLOCKED PUT ITEM, CW=OK ", "LCD PROCESS giver");
        show(ST_PROCESS, '1', "10", "SLOT 3 UNLOCKED TAKE ITEM,CW=OK ", "LCD PROCESS receiver");
        show(ST_DONE,    '0', "10", "SLOT 3 LOCKED   THANK YOU GIVER!", "LCD DONE giver");
        show(ST_DONE,    '1', "10", "SLOT 3 LOCKED   HAVE A NICE DAY ", "LCD DONE receiver");
        show(ST_ROLE,    '1', "00", "ROLE: RECEIVER  NO ITEMS YET    ", "LCD receiver, no items");
        occ <= "111";
        show(ST_ROLE,    '0', "00", "ROLE: GIVER     ALL SLOTS FULL  ", "LCD giver, all full");
        show(ST_ROLE,    '1', "00", "ROLE: RECEIVER  <SWIPE> CW=OK   ", "LCD receiver, items available");
        show(ST_IDLE,    '0', "00", " Drop and Pick !SWIPE  ITEMS:3/3", "LCD IDLE 3/3");
        ok <= '0';
        show(ST_DONE,    '0', "01", "SLOT 2 LOCKED   CANCELLED       ", "LCD DONE cancelled");
        check(timing_err = 0, "HD44780 timing ok (" & integer'image(timing_err) & " violations)");

        if errors = 0 then report "===== ALL TESTS PASSED =====" severity note;
        else report "===== " & integer'image(errors) & " TEST(S) FAILED =====" severity error;
        end if;
        finished <= true;
        wait;
    end process;
end architecture;
