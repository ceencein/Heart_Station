# ============================================================
# make_board1.tcl  Creates the Vivado project for BOARD 1 in one step
#
# How to use: Vivado start page -> Tools -> Run Tcl Script... -> choose this file
#   (or in the Tcl Console:  source C:/fpga/locker_final/make_board1.tcl )
# The project is created in the folder vivado_board1 next to this script.
# Keep the folder path short, without spaces or Thai letters (e.g. C:/fpga/locker_final).
# ============================================================
set here [file normalize [file dirname [info script]]]

create_project board1 $here/vivado_board1 -part xc7s15ftgb196-1 -force
set_property target_language VHDL [current_project]

# design files: every .vhd in the board1 folder (each file only once)
add_files -norecurse [glob $here/board1/*.vhd]
set_property top board1 [current_fileset]

# pin constraints
add_files -fileset constrs_1 -norecurse $here/board1/board1.xdc

# simulation files (optional, only used by Run Simulation)
add_files -fileset sim_1 -norecurse [list $here/sim/tb_board1.vhd $here/sim/tb_sensor.vhd $here/sim/tb_uart.vhd $here/sim/sim_paj7620_model.vhd]
set_property top tb_board1 [get_filesets sim_1]

# also write a .bin file for flash programming
set_property STEPS.WRITE_BITSTREAM.ARGS.BIN_FILE true [get_runs impl_1]

update_compile_order -fileset sources_1
puts "Project board1 created in $here/vivado_board1 - next: Generate Bitstream"
