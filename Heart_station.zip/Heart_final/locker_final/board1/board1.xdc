## ============================================================
## board1.xdc - BOARD 1 (top: board1)  EDGE Spartan-7 XC7S15 (xc7s15ftgb196-1)
## Pins checked against the vendor file EDGE_Spartan7_Pins_Details.xdc
## ============================================================

## Clock 50 MHz
set_property -dict { PACKAGE_PIN H11 IOSTANDARD LVCMOS33 } [get_ports { clk }];
create_clock -period 20.000 -name sys_clk [get_ports { clk }];

## Push buttons (pressed = 1)
set_property -dict { PACKAGE_PIN J13 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[0] }]; # top    = CONFIRM
set_property -dict { PACKAGE_PIN L13 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[1] }]; # bottom = CANCEL
set_property -dict { PACKAGE_PIN J14 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[2] }]; # left   = PREV
set_property -dict { PACKAGE_PIN J11 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[3] }]; # right  = NEXT
set_property -dict { PACKAGE_PIN J12 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports { pb[4] }]; # center = reset

## LEDs 0-7 (put jumper J4 on GND to enable)
set_property -dict { PACKAGE_PIN K12 IOSTANDARD LVCMOS33 } [get_ports { led[0] }];
set_property -dict { PACKAGE_PIN M12 IOSTANDARD LVCMOS33 } [get_ports { led[1] }];
set_property -dict { PACKAGE_PIN M14 IOSTANDARD LVCMOS33 } [get_ports { led[2] }];
set_property -dict { PACKAGE_PIN P13 IOSTANDARD LVCMOS33 } [get_ports { led[3] }];
set_property -dict { PACKAGE_PIN N11 IOSTANDARD LVCMOS33 } [get_ports { led[4] }];
set_property -dict { PACKAGE_PIN P11 IOSTANDARD LVCMOS33 } [get_ports { led[5] }];
set_property -dict { PACKAGE_PIN L5  IOSTANDARD LVCMOS33 } [get_ports { led[6] }];
set_property -dict { PACKAGE_PIN M4  IOSTANDARD LVCMOS33 } [get_ports { led[7] }];

## 7-segment, 4 digits (common anode). Remove jumper J9: LEDs D10-D17 share these pins
set_property -dict { PACKAGE_PIN H4 IOSTANDARD LVCMOS33 } [get_ports { digit[0] }];
set_property -dict { PACKAGE_PIN H3 IOSTANDARD LVCMOS33 } [get_ports { digit[1] }];
set_property -dict { PACKAGE_PIN H2 IOSTANDARD LVCMOS33 } [get_ports { digit[2] }];
set_property -dict { PACKAGE_PIN H1 IOSTANDARD LVCMOS33 } [get_ports { digit[3] }];
set_property -dict { PACKAGE_PIN L3 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[7] }]; # A
set_property -dict { PACKAGE_PIN P4 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[6] }]; # B
set_property -dict { PACKAGE_PIN P2 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[5] }]; # C
set_property -dict { PACKAGE_PIN M3 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[4] }]; # D
set_property -dict { PACKAGE_PIN M1 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[3] }]; # E
set_property -dict { PACKAGE_PIN J4 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[2] }]; # F
set_property -dict { PACKAGE_PIN K4 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[1] }]; # G
set_property -dict { PACKAGE_PIN J2 IOSTANDARD LVCMOS33 } [get_ports { Seven_Segment[0] }]; # DP

## ---------------- Expansion connector J5 ----------------
## pin1 = 5V, pin2 = NC, pin3 = 3V3, pin4 = GND
## Connect J5 pins 4, 5, 6 of board 1 to the SAME pins of board 2 (straight across)

## UART link to board 2 (115200 baud, 8N1)
set_property -dict { PACKAGE_PIN L14 IOSTANDARD LVCMOS33 } [get_ports { uart_tx }];              # J5 pin5 -> board 2 pin5 (its RX)
set_property -dict { PACKAGE_PIN M13 IOSTANDARD LVCMOS33 PULLUP true } [get_ports { uart_rx }]; # J5 pin6 <- board 2 pin6 (its TX)
## J5 pin7 (H14), pin8 (H13) now free

## PAJ7620 gesture sensor (VIN -> J5 pin3 3.3V, GND -> J5 pin4)
set_property -dict { PACKAGE_PIN F11 IOSTANDARD LVCMOS33 PULLUP true } [get_ports { paj_scl }]; # J5 pin9
set_property -dict { PACKAGE_PIN G11 IOSTANDARD LVCMOS33 PULLUP true } [get_ports { paj_sda }]; # J5 pin10

## Buzzer (put jumper J6 on Enable)
set_property -dict { PACKAGE_PIN B14 IOSTANDARD LVCMOS33 } [get_ports { Buzzer }];

## Config
set_property CFGBVS VCCO [current_design];
set_property CONFIG_VOLTAGE 3.3 [current_design];
