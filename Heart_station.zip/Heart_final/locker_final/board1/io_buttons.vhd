-- ============================================================
-- io_buttons.vhd  4 push buttons -> 1-clock pulse on each press (used on both boards)
--
--   pb(0) top   pb(1) bottom   pb(2) left   pb(3) right
--   each button: io_debounce (synchronizer + 10 ms stable filter + edge detect)
--   rise(i) = 1-clock pulse when button i is pressed
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;

entity io_buttons is
    generic (
        CLK_HZ : integer := 50_000_000
    );
    port (
        clk  : in  std_logic;
        rst  : in  std_logic;
        pb   : in  std_logic_vector(3 downto 0);
        rise : out std_logic_vector(3 downto 0)
    );
end entity;

architecture rtl of io_buttons is
begin
    g_btn : for i in 0 to 3 generate
        u_db : entity work.io_debounce
            generic map (STABLE_CYC => CLK_HZ / 100)          -- 10 ms
            port map (clk => clk, rst => rst, din => pb(i),
                      level => open, rise => rise(i), fall => open);
    end generate;
end architecture;
