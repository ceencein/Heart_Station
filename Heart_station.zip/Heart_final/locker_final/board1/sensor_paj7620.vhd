-- ============================================================
-- sensor_paj7620.vhd  (board 1)  PAJ7620 gesture sensor
--
-- This file holds 2 entities:
--   sensor_paj7620_rom : init table (220 register/value pairs)
--   sensor_paj7620     : controller (wake, init, poll gestures, auto recovery)
--
-- ------------------------------------------------------------
-- sensor_paj7620 (controller)
--
-- Controls the PAJ7620 gesture sensor over I2C (address 0x73)
--
-- Sequence (FSM):
--   1) S_PWR      wait 50 ms for power to settle
--   2) S_WAKE*    wake the sensor: read register 0x00 twice, 5 ms apart
--                 2nd read must return 0x20 (otherwise set sensor_err and retry every 100 ms)
--   3) S_INIT*    write the init values from sensor_paj7620_rom one pair at a time (220 pairs)
--   4) S_POLL*    read register 0x43 (gesture result) every POLL_MS
--                 if non-zero and it passes the filter -> map to a command, pulse gest_valid
--
-- Noise filter (set by generics):
--   POLL_MS      read the sensor every N ms (smaller = faster response)        default 10
--   HOLD_MS      after a gesture is accepted, ignore new ones for N ms (stops doubles /
--                the hand pulling back). 0 = off, large = less noise but no quick repeats  default 150
--   REJECT_MULTI drop readings with more than one bit set (sensor unsure)       default true
--
-- Auto recovery (sensor moved, loose wire, power glitch):
--   ERR_LIMIT    after N I2C errors in a row while polling, start again from S_PWR
--                (wake + full 220-pair init). A NACK during init also restarts.
--                A sensor that lost power forgets all its settings, so without this
--                it would stay silent until the board is reset.             default 5
--   CHECK_MS     health check: every N ms, read the Part ID (reg 0x00, must be 0x20)
--                instead of 0x43. A wrong value means the sensor or the bus is stuck
--                (e.g. SDA held low reads as 0x00 with no I2C error) -> recover.
--                0 = off                                                     default 1000
--   IDLE_REINIT_S if no gesture was seen for N seconds, re-send the 220 init pairs
--                anyway (~0.1 s blind). Catches a sensor that still answers I2C but
--                whose gesture engine stopped. 0 = off                       default 60
--   Every recovery starts with an I2C bus clear: 9 SCL pulses with SDA released,
--   then a STOP, so a sensor stuck in the middle of a byte lets go of SDA.
--   recover = 1-clock pulse each time a recovery starts (for a debug LED / counter)
--
-- Sensor settings (passed to sensor_paj7620_rom, which overwrites the table values):
--   START_TH  R_GestureStartTh  (Bank0 0x84/0x85, 10 bits)  original 0x20
--   END_TH    R_GestureEndTh    (Bank0 0x86/0x87, 10 bits)  original 0x10
--   LIGHT_TH  R_LightThd        (Bank0 0x83)                original 0x20
--   OBJ_MIN_Z R_ObjectMinZ      (Bank0 0x88, 5 bits)        original 0x05
--   OBJ_MAX_Z R_ObjectMaxZ      (Bank0 0x89, 6 bits)        original 0x18
--   The datasheet only names these registers; change one at a time and test on the board
--
-- Register 0x43 (Bank 0), one bit per gesture:
--   bit0 bit1 bit2 bit3 = 4 swipe directions, bit4 = Forward (push in),
--   bit5 = Backward (pull out), bit6/bit7 = clockwise / counter-clockwise
--
-- Gesture -> command : only 4 gestures, bit numbers set by generics (others send nothing)
--   NEXT_BIT    = 3  swipe right        -> NEXT     next slot
--   PREV_BIT    = 2  swipe left         -> PREV     previous slot
--   CONFIRM_BIT = 6  clockwise          -> CONFIRM  unlock / lock
--   CANCEL_BIT  = 7  counter-clockwise  -> CANCEL   cancel / lock
--   If directions differ on the real board, read register 0x43 on the LEDs to find the right bit
-- ============================================================

-- ============================================================
-- sensor_paj7620_rom  (board 1)
--
-- PAJ7620 init table, 220 pairs
-- Each entry is 16 bits = (8-bit register number) & (8-bit value)
-- Source: standard init array of the PAJ7620 libraries (Seeed / Elecfreaks)
--
--   x"EF00" = select register Bank 0,  x"EF01" = Bank 1
--   The last pair x"EF00" switches back to Bank 0 so gesture results can be read at 0x43
--
-- The sensor-setting generics (defaults = original table values) are written into the
-- table at elaboration time (function patch), so it is still a plain ROM with no extra logic
--   START_TH  -> Bank0 0x84 (bits 7..0) / 0x85 (bits 9..8)   R_GestureStartTh
--   END_TH    -> Bank0 0x86 (bits 7..0) / 0x87 (bits 9..8)   R_GestureEndTh
--   LIGHT_TH  -> Bank0 0x83                                R_LightThd
--   OBJ_MIN_Z -> Bank0 0x88                                R_ObjectMinZ
--   OBJ_MAX_Z -> Bank0 0x89                                R_ObjectMaxZ
--
-- Combinational ROM : idx in -> paj_rom out
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity sensor_paj7620_rom is
    generic (
        START_TH  : integer := 16#20#;
        END_TH    : integer := 16#10#;
        LIGHT_TH  : integer := 16#20#;
        OBJ_MIN_Z : integer := 16#05#;
        OBJ_MAX_Z : integer := 16#18#
    );
    port (
        idx     : in  unsigned(8 downto 0);
        paj_rom : out std_logic_vector(15 downto 0)   -- reg_addr & data
    );
end entity;

architecture rtl of sensor_paj7620_rom is
    constant ROM_N : integer := 220;
    type rom_t is array (0 to ROM_N - 1) of std_logic_vector(15 downto 0);
    constant ROM : rom_t := (
        x"EF00", x"3229", x"3301", x"3400", x"3501", x"3600",
        x"3707", x"3817", x"3906", x"3A12", x"3F00", x"4002",
        x"41FF", x"4201", x"462D", x"470F", x"483C", x"4900",
        x"4A1E", x"4B00", x"4C20", x"4D00", x"4E1A", x"4F14",
        x"5000", x"5110", x"5200", x"5C02", x"5D00", x"5E10",
        x"5F3F", x"6027", x"6128", x"6200", x"6303", x"64F7",
        x"6503", x"66D9", x"6703", x"6801", x"69C8", x"6A40",
        x"6D04", x"6E00", x"6F00", x"7080", x"7100", x"7200",
        x"7300", x"74F0", x"7500", x"8042", x"8144", x"8204",
        x"8320", x"8420", x"8500", x"8610", x"8700", x"8805",
        x"8918", x"8A10", x"8B01", x"8C37", x"8D00", x"8EF0",
        x"8F81", x"9006", x"9106", x"921E", x"930D", x"940A",
        x"950A", x"960C", x"9705", x"980A", x"9941", x"9A14",
        x"9B0A", x"9C3F", x"9D33", x"9EAE", x"9FF9", x"A048",
        x"A113", x"A210", x"A308", x"A430", x"A519", x"A610",
        x"A708", x"A824", x"A904", x"AA1E", x"AB1E", x"CC19",
        x"CD0B", x"CE13", x"CF64", x"D021", x"D10F", x"D288",
        x"E001", x"E104", x"E241", x"E3D6", x"E400", x"E50C",
        x"E60A", x"E700", x"E800", x"E900", x"EE07", x"EF01",
        x"001E", x"011E", x"020F", x"0310", x"0402", x"0500",
        x"06B0", x"0704", x"080D", x"090E", x"0A9C", x"0B04",
        x"0C05", x"0D0F", x"0E02", x"0F12", x"1002", x"1102",
        x"1200", x"1301", x"1405", x"1507", x"1605", x"1707",
        x"1801", x"1904", x"1A05", x"1B0C", x"1C2A", x"1D01",
        x"1E00", x"2100", x"2200", x"2300", x"2501", x"2600",
        x"2739", x"287F", x"2908", x"3003", x"3100", x"321A",
        x"331A", x"3407", x"3507", x"3601", x"37FF", x"3836",
        x"3907", x"3A00", x"3EFF", x"3F00", x"4077", x"4140",
        x"4200", x"4330", x"44A0", x"455C", x"4600", x"4700",
        x"4858", x"4A1E", x"4B1E", x"4C00", x"4D00", x"4EA0",
        x"4F80", x"5000", x"5100", x"5200", x"5300", x"5400",
        x"5780", x"5910", x"5A08", x"5B94", x"5CE8", x"5D08",
        x"5E3D", x"5F99", x"6045", x"6140", x"632D", x"6402",
        x"6596", x"6600", x"6797", x"6801", x"69CD", x"6A01",
        x"6BB0", x"6C04", x"6D2C", x"6E01", x"6F32", x"7100",
        x"7201", x"7335", x"7400", x"7533", x"7631", x"7701",
        x"7C84", x"7D03", x"7E01", x"EF00"
    );

    function byte(v : integer) return std_logic_vector is
    begin
        return std_logic_vector(to_unsigned(v mod 256, 8));
    end function;

    -- Write the settings into the table, only for Bank 0 registers
    function patch(r : rom_t) return rom_t is
        variable o    : rom_t := r;
        variable bank : integer := 0;
        variable reg  : std_logic_vector(7 downto 0);
    begin
        for i in r'range loop
            reg := r(i)(15 downto 8);
            if reg = x"EF" then
                bank := to_integer(unsigned(r(i)(7 downto 0)));
            elsif bank = 0 then
                case reg is
                    when x"83"  => o(i)(7 downto 0) := byte(LIGHT_TH);
                    when x"84"  => o(i)(7 downto 0) := byte(START_TH);
                    when x"85"  => o(i)(7 downto 0) := byte(START_TH / 256);
                    when x"86"  => o(i)(7 downto 0) := byte(END_TH);
                    when x"87"  => o(i)(7 downto 0) := byte(END_TH / 256);
                    when x"88"  => o(i)(7 downto 0) := byte(OBJ_MIN_Z);
                    when x"89"  => o(i)(7 downto 0) := byte(OBJ_MAX_Z);
                    when others => null;
                end case;
            end if;
        end loop;
        return o;
    end function;

    constant ROM_P : rom_t := patch(ROM);
begin
    paj_rom <= ROM_P(to_integer(idx)) when to_integer(idx) < ROM_N else x"EF00";
end architecture;


library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity sensor_paj7620 is
    generic (
        CLK_HZ       : integer := 50_000_000;
        POLL_MS      : integer := 10;
        HOLD_MS      : integer := 150;
        REJECT_MULTI : boolean := true;
        ERR_LIMIT    : integer := 5;
        CHECK_MS     : integer := 1000;
        IDLE_REINIT_S : integer := 60;
        START_TH     : integer := 16#20#;
        END_TH       : integer := 16#10#;
        LIGHT_TH     : integer := 16#20#;
        OBJ_MIN_Z    : integer := 16#05#;
        OBJ_MAX_Z    : integer := 16#18#;
        NEXT_BIT     : integer := 3;          -- swipe right
        PREV_BIT     : integer := 2;          -- swipe left
        CONFIRM_BIT  : integer := 6;          -- clockwise
        CANCEL_BIT   : integer := 7           -- counter-clockwise
    );
    port (
        clk        : in  std_logic;
        rst        : in  std_logic;
        gest_valid : out std_logic;                     -- 1-clock pulse on a new command gesture
        gest_cmd   : out std_logic_vector(2 downto 0);
        gest_raw   : out std_logic_vector(7 downto 0);  -- raw value of 0x43
        raw_valid  : out std_logic;                     -- 1-clock pulse for every gesture that passes the filter
        init_done  : out std_logic;
        sensor_err : out std_logic;
        recover    : out std_logic;                     -- 1-clock pulse when a recovery starts
        scl_o      : out std_logic;
        sda_o      : out std_logic;
        sda_i      : in  std_logic
    );
end entity;

architecture rtl of sensor_paj7620 is

    constant PAJ_ADDR : std_logic_vector(6 downto 0) := "1110011";  -- 0x73
    constant ROM_N    : integer := 220;
    constant MS       : integer := CLK_HZ / 1000;

    type state_t is (S_BUSCLR, S_PWR, S_WAKE1, S_WAKE1_W, S_DLY5, S_WAKE2, S_WAKE2_W,
                     S_RETRY, S_INIT, S_INIT_W, S_POLL_DLY, S_POLL, S_POLL_W,
                     S_CHK, S_CHK_W);
    signal st  : state_t := S_PWR;
    -- if a glitch ever puts st in an unused code, Vivado returns it to the reset state
    attribute fsm_safe_state : string;
    attribute fsm_safe_state of st : signal is "reset_state";
    signal tmr : integer range 0 to 100 * MS := 0;
    signal hold_cnt : integer range 0 to HOLD_MS * MS := 0;   -- remaining hold time after a gesture
    signal err_cnt  : integer range 0 to ERR_LIMIT := 0;      -- I2C errors in a row while polling

    -- health check / idle re-init (counted in ms)
    signal ms_cnt   : integer range 0 to MS - 1 := 0;
    signal chk_ms   : integer range 0 to CHECK_MS := 0;
    signal idle_ms  : integer range 0 to IDLE_REINIT_S * 1000 := 0;

    -- bus clear: 21 steps of 5 us
    constant BC_T   : integer := CLK_HZ / 200_000;            -- 5 us
    signal bc_step  : integer range 0 to 21 := 0;
    signal bc_tmr   : integer range 0 to BC_T := 0;
    signal bc_scl, bc_sda : std_logic := '1';
    signal m_scl, m_sda   : std_logic;                        -- from sensor_i2c
    signal rec_r    : std_logic := '0';

    -- I2C master
    signal i2c_start  : std_logic := '0';
    signal i2c_mode   : std_logic_vector(1 downto 0) := "00";
    signal i2c_reg    : std_logic_vector(7 downto 0) := (others => '0');
    signal i2c_wdata  : std_logic_vector(7 downto 0) := (others => '0');
    signal i2c_rdata  : std_logic_vector(7 downto 0);
    signal i2c_busy, i2c_done, i2c_ackerr : std_logic;

    -- ROM
    signal idx   : unsigned(8 downto 0) := (others => '0');
    signal rom_q : std_logic_vector(15 downto 0);

    -- Internal copies (VHDL-93 cannot read an out port)
    signal valid_r : std_logic := '0';
    signal rawv_r  : std_logic := '0';
    signal cmd_r   : std_logic_vector(2 downto 0) := (others => '0');
    signal raw_r   : std_logic_vector(7 downto 0) := (others => '0');
    signal done_r  : std_logic := '0';
    signal err_r   : std_logic := '0';

    -- Count the bits that are set
    function ones(g : std_logic_vector(7 downto 0)) return integer is
        variable n : integer := 0;
    begin
        for i in 0 to 7 loop
            if g(i) = '1' then n := n + 1; end if;
        end loop;
        return n;
    end function;

    function map_gesture(g : std_logic_vector(7 downto 0)) return std_logic_vector is
    begin
        if    g(NEXT_BIT)    = '1' then return CMD_NEXT;
        elsif g(PREV_BIT)    = '1' then return CMD_PREV;
        elsif g(CONFIRM_BIT) = '1' then return CMD_CONFIRM;
        elsif g(CANCEL_BIT)  = '1' then return CMD_CANCEL;
        else                            return CMD_NONE;   -- other gestures (up/down/forward/backward) unused
        end if;
    end function;

begin

    gest_valid <= valid_r;
    gest_cmd   <= cmd_r;
    gest_raw   <= raw_r;
    raw_valid  <= rawv_r;
    init_done  <= done_r;
    sensor_err <= err_r;

    u_i2c : entity work.sensor_i2c
        generic map (CLK_HZ => CLK_HZ, I2C_HZ => 100_000)
        port map (
            clk => clk, rst => rst,
            start => i2c_start, mode => i2c_mode,
            dev_addr => PAJ_ADDR, reg_addr => i2c_reg, wdata => i2c_wdata,
            rdata => i2c_rdata, busy => i2c_busy, done => i2c_done, ack_err => i2c_ackerr,
            scl_o => m_scl, sda_o => m_sda, sda_i => sda_i
        );

    -- During bus clear the controller drives the lines itself
    scl_o   <= bc_scl when st = S_BUSCLR else m_scl;
    sda_o   <= bc_sda when st = S_BUSCLR else m_sda;
    recover <= rec_r;

    u_rom : entity work.sensor_paj7620_rom
        generic map (START_TH => START_TH, END_TH => END_TH, LIGHT_TH => LIGHT_TH,
                     OBJ_MIN_Z => OBJ_MIN_Z, OBJ_MAX_Z => OBJ_MAX_Z)
        port map (idx => idx, paj_rom => rom_q);

    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                st        <= S_PWR;
                tmr       <= 0;
                idx       <= (others => '0');
                i2c_start <= '0';
                i2c_mode  <= "00";
                i2c_reg   <= (others => '0');
                i2c_wdata <= (others => '0');
                valid_r   <= '0';
                rawv_r    <= '0';
                cmd_r     <= CMD_NONE;
                raw_r     <= (others => '0');
                done_r    <= '0';
                err_r     <= '0';
                hold_cnt  <= 0;
                err_cnt   <= 0;
                ms_cnt    <= 0;
                chk_ms    <= 0;
                idle_ms   <= 0;
                bc_step   <= 0;
                bc_tmr    <= 0;
                bc_scl    <= '1';
                bc_sda    <= '1';
                rec_r     <= '0';
            else
                rec_r <= '0';

                -- ms tick for the health check and the idle timer (only while polling)
                if done_r = '1' then
                    if ms_cnt = MS - 1 then
                        ms_cnt <= 0;
                        if chk_ms  < CHECK_MS             then chk_ms  <= chk_ms + 1;  end if;
                        if idle_ms < IDLE_REINIT_S * 1000 then idle_ms <= idle_ms + 1; end if;
                    else
                        ms_cnt <= ms_cnt + 1;
                    end if;
                else
                    ms_cnt  <= 0;
                    chk_ms  <= 0;
                    idle_ms <= 0;
                end if;

                if hold_cnt /= 0 then hold_cnt <= hold_cnt - 1; end if;

                i2c_start <= '0';
                valid_r   <= '0';
                rawv_r    <= '0';

                case st is
                    -- ---------- I2C bus clear: 9 clocks with SDA released, then STOP ----------
                    --   steps 0..17 : SCL low / high x 9      step 18 : SCL low,  SDA low
                    --   step 19     : SCL high, SDA low        step 20 : SCL high, SDA high (STOP)
                    when S_BUSCLR =>
                        if bc_tmr >= BC_T - 1 then
                            bc_tmr <= 0;
                            if bc_step = 20 then
                                bc_step <= 0;
                                bc_scl  <= '1';
                                bc_sda  <= '1';
                                tmr     <= 0;
                                st      <= S_PWR;
                            else
                                bc_step <= bc_step + 1;
                            end if;
                            if bc_step + 1 <= 17 then
                                if (bc_step + 1) mod 2 = 0 then bc_scl <= '0'; else bc_scl <= '1'; end if;
                                bc_sda <= '1';
                            elsif bc_step + 1 = 18 then
                                bc_scl <= '0'; bc_sda <= '0';
                            elsif bc_step + 1 = 19 then
                                bc_scl <= '1'; bc_sda <= '0';
                            else
                                bc_scl <= '1'; bc_sda <= '1';
                            end if;
                        else
                            bc_tmr <= bc_tmr + 1;
                        end if;

                    -- ---------- Wait for power ----------
                    when S_PWR =>
                        if tmr >= 50 * MS then tmr <= 0; st <= S_WAKE1;
                        else tmr <= tmr + 1; end if;

                    -- ---------- Wake the sensor (first read may get no ACK) ----------
                    when S_WAKE1 =>
                        i2c_mode <= "10"; i2c_reg <= x"00"; i2c_start <= '1';
                        st <= S_WAKE1_W;
                    when S_WAKE1_W =>
                        if i2c_done = '1' then st <= S_DLY5; end if;
                    when S_DLY5 =>
                        if tmr >= 5 * MS then tmr <= 0; st <= S_WAKE2;
                        else tmr <= tmr + 1; end if;
                    when S_WAKE2 =>
                        i2c_mode <= "10"; i2c_reg <= x"00"; i2c_start <= '1';
                        st <= S_WAKE2_W;
                    when S_WAKE2_W =>
                        if i2c_done = '1' then
                            if i2c_ackerr = '0' and i2c_rdata = x"20" then
                                err_r <= '0';
                                idx   <= (others => '0');
                                st    <= S_INIT;
                            else
                                err_r <= '1';
                                st    <= S_RETRY;
                            end if;
                        end if;
                    when S_RETRY =>
                        if tmr >= 100 * MS then
                            tmr     <= 0;
                            bc_step <= 0; bc_tmr <= 0; bc_scl <= '0'; bc_sda <= '1';
                            st      <= S_BUSCLR;
                        else tmr <= tmr + 1; end if;

                    -- ---------- Write init values one pair at a time ----------
                    when S_INIT =>
                        i2c_mode  <= "01";
                        i2c_reg   <= rom_q(15 downto 8);
                        i2c_wdata <= rom_q(7 downto 0);
                        i2c_start <= '1';
                        st <= S_INIT_W;
                    when S_INIT_W =>
                        if i2c_done = '1' then
                            if i2c_ackerr = '1' then
                                err_r <= '1';                -- sensor lost: restart from wake-up
                                tmr   <= 0;
                                st    <= S_RETRY;
                            elsif to_integer(idx) = ROM_N - 1 then
                                done_r <= '1';
                                tmr    <= 0;
                                st     <= S_POLL_DLY;
                            else
                                idx <= idx + 1;
                                st  <= S_INIT;
                            end if;
                        end if;

                    -- ---------- Poll for gestures ----------
                    when S_POLL_DLY =>
                        if tmr >= POLL_MS * MS then
                            tmr <= 0;
                            if IDLE_REINIT_S > 0 and idle_ms >= IDLE_REINIT_S * 1000 then
                                rec_r   <= '1';              -- quiet too long: refresh the sensor
                                done_r  <= '0';
                                bc_step <= 0; bc_tmr <= 0; bc_scl <= '0'; bc_sda <= '1';
                                st      <= S_BUSCLR;
                            elsif CHECK_MS > 0 and chk_ms >= CHECK_MS then
                                chk_ms <= 0;
                                st     <= S_CHK;
                            else
                                st <= S_POLL;
                            end if;
                        else tmr <= tmr + 1; end if;

                    -- ---------- Health check: Part ID must still read 0x20 ----------
                    when S_CHK =>
                        i2c_mode <= "10"; i2c_reg <= x"00"; i2c_start <= '1';
                        st <= S_CHK_W;
                    when S_CHK_W =>
                        if i2c_done = '1' then
                            if i2c_ackerr = '0' and i2c_rdata = x"20" then
                                st <= S_POLL_DLY;
                            else
                                err_r   <= '1';              -- sensor or bus stuck
                                rec_r   <= '1';
                                done_r  <= '0';
                                bc_step <= 0; bc_tmr <= 0; bc_scl <= '0'; bc_sda <= '1';
                                st      <= S_BUSCLR;
                            end if;
                        end if;
                    when S_POLL =>
                        i2c_mode <= "10"; i2c_reg <= x"43"; i2c_start <= '1';
                        st <= S_POLL_W;
                    when S_POLL_W =>
                        if i2c_done = '1' then
                            -- Filter: gesture present, hold time over, and (if enabled) single bit
                            if i2c_ackerr = '0' and i2c_rdata /= x"00"
                               and hold_cnt = 0
                               and (not REJECT_MULTI or ones(i2c_rdata) = 1) then
                                raw_r    <= i2c_rdata;
                                rawv_r   <= '1';
                                idle_ms  <= 0;               -- sensor is alive
                                hold_cnt <= HOLD_MS * MS;
                                if map_gesture(i2c_rdata) /= CMD_NONE then
                                    cmd_r   <= map_gesture(i2c_rdata);
                                    valid_r <= '1';
                                end if;
                            end if;
                            err_r <= i2c_ackerr;
                            st    <= S_POLL_DLY;
                            -- Recovery: too many errors in a row -> power-up sequence + re-init
                            if i2c_ackerr = '1' then
                                if err_cnt >= ERR_LIMIT - 1 then
                                    err_cnt <= 0;
                                    done_r  <= '0';
                                    rec_r   <= '1';
                                    bc_step <= 0; bc_tmr <= 0; bc_scl <= '0'; bc_sda <= '1';
                                    st      <= S_BUSCLR;
                                else
                                    err_cnt <= err_cnt + 1;
                                end if;
                            else
                                err_cnt <= 0;
                            end if;
                        end if;
                end case;
            end if;
        end if;
    end process;

end architecture;
