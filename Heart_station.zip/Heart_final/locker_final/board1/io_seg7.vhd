-- ============================================================
-- io_seg7.vhd  (both boards)  Multiplexed 4-digit 7-segment driver for the EDGE board
--
-- The EDGE board display is common anode
--   Seven_Segment(7 downto 0) = a b c d e f g dp   segment on when '0' (active low)
--   digit(3 downto 0)         = digit select       digit on when '1'
--
-- Digit order : the vendor XDC says digit[0] (H4) = left-most, digit[3] (H1) = right-most
--   LEFT_IS_DIGIT0 = true  (default, per vendor XDC) : sym3 -> digit(0)
--   LEFT_IS_DIGIT0 = false                              : sym3 -> digit(3)
--   If digits appear reversed on the real board, flip this in the top level
--
-- Method: 17-bit counter, top 2 bits select the digit (~380 Hz per digit)
--         -> 2-to-4 decoder selects the digit, 4-to-1 MUX selects the value
--         -> decoder converts the code into the 7-segment pattern
--
-- 4-bit symbol codes: 0-9 digits, A '-', B 'G', C 'r', D 'E', F blank
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity io_seg7 is
    generic (
        LEFT_IS_DIGIT0 : boolean := true
    );
    port (
        clk           : in  std_logic;
        rst           : in  std_logic;
        sym3          : in  unsigned(3 downto 0);   -- left-most digit
        sym2          : in  unsigned(3 downto 0);
        sym1          : in  unsigned(3 downto 0);
        sym0          : in  unsigned(3 downto 0);   -- right-most digit
        digit         : out std_logic_vector(3 downto 0);
        Seven_Segment : out std_logic_vector(7 downto 0)
    );
end entity;

architecture rtl of io_seg7 is
    signal refresh : unsigned(16 downto 0) := (others => '0');
    signal sel     : unsigned(1 downto 0);
    signal cur     : unsigned(3 downto 0);
    signal d0, d1, d2, d3 : unsigned(3 downto 0);   -- values sent to digit(0..3)
begin
    -- Put digits in the board's order
    d0 <= sym3 when LEFT_IS_DIGIT0 else sym0;
    d1 <= sym2 when LEFT_IS_DIGIT0 else sym1;
    d2 <= sym1 when LEFT_IS_DIGIT0 else sym2;
    d3 <= sym0 when LEFT_IS_DIGIT0 else sym3;

    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then refresh <= (others => '0');
            else              refresh <= refresh + 1;
            end if;
        end if;
    end process;

    sel <= refresh(16 downto 15);

    -- MUX 4->1 + Decoder 2->4
    with sel select cur <=
        d0 when "00",
        d1 when "01",
        d2 when "10",
        d3 when others;

    with sel select digit <=
        "0001" when "00",
        "0010" when "01",
        "0100" when "10",
        "1000" when others;

    -- code -> 7-segment pattern     abcdefg dp
    with cur select Seven_Segment <=
        "00000011" when x"0",
        "10011111" when x"1",
        "00100101" when x"2",
        "00001101" when x"3",
        "10011001" when x"4",
        "01001001" when x"5",
        "01000001" when x"6",
        "00011111" when x"7",
        "00000001" when x"8",
        "00001001" when x"9",
        "11111101" when x"A",    -- -
        "01000011" when x"B",    -- G
        "11110101" when x"C",    -- r
        "01100001" when x"D",    -- E
        "11111111" when others;  -- blank
end architecture;
