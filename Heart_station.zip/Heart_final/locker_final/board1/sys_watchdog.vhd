-- ============================================================
-- sys_watchdog.vhd  Watchdog: resets the board by itself when it has been quiet too long
--
-- Same effect as pressing the center (reset) button. Used on board 1 because a
-- board left on for a long time can stop answering until it is reset by hand,
-- and the button cannot be reached once the board is inside the cabinet.
--
--   kick      : pulse whenever the board does useful work (a command was sent)
--   TIMEOUT_S : seconds without a kick before the reset   (0 = watchdog off)
--   wdt_rst   : '1' for PULSE_MS ms, OR it into the board reset
--
-- The watchdog uses only the power-on reset (por), never its own output, so it
-- keeps counting through the reset it generates. While nobody uses the board it
-- fires once every TIMEOUT_S seconds; each time the sensor is set up again (~0.2 s).
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;

entity sys_watchdog is
    generic (
        CLK_HZ    : integer := 50_000_000;
        TIMEOUT_S : integer := 120;
        PULSE_MS  : integer := 2
    );
    port (
        clk     : in  std_logic;
        por     : in  std_logic;     -- power-on reset only
        kick    : in  std_logic;     -- activity pulse
        wdt_rst : out std_logic
    );
end entity;

architecture rtl of sys_watchdog is
    constant MS     : integer := CLK_HZ / 1000;
    signal ms_cnt   : integer range 0 to MS - 1 := 0;
    signal idle_ms  : integer range 0 to TIMEOUT_S * 1000 := 0;
    signal p_cnt    : integer range 0 to PULSE_MS := 0;
    signal rst_r    : std_logic := '0';
begin
    wdt_rst <= rst_r;

    process (clk)
    begin
        if rising_edge(clk) then
            if por = '1' or TIMEOUT_S = 0 then
                ms_cnt   <= 0;
                idle_ms  <= 0;
                p_cnt    <= 0;
                rst_r    <= '0';
            elsif kick = '1' then
                idle_ms <= 0;                          -- board is in use
            elsif ms_cnt = MS - 1 then
                ms_cnt <= 0;
                if p_cnt /= 0 then                  -- reset pulse running
                    p_cnt <= p_cnt - 1;
                    if p_cnt = 1 then rst_r <= '0'; end if;
                elsif idle_ms = TIMEOUT_S * 1000 - 1 then
                    idle_ms  <= 0;                     -- quiet too long -> reset
                    p_cnt    <= PULSE_MS;
                    rst_r    <= '1';
                else
                    idle_ms <= idle_ms + 1;
                end if;
            else
                ms_cnt <= ms_cnt + 1;
            end if;
        end if;
    end process;
end architecture;
