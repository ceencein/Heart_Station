-- ============================================================
-- io_buzzer.vhd  (board 1)  Sound feedback for the user
--
--   beep_short : pulse -> one beep 200 ms           (NEXT / PREV / CANCEL accepted)
--   beep_long  : pulse -> one beep 500 ms           (CONFIRM accepted)
--   beep_err   : pulse -> two short beeps 100-100-100 ms
--                (board 2 rejected the command, or board 2 did not answer)
--
-- The EDGE board buzzer is an ACTIVE buzzer: it sounds by itself while the pin is '1'
-- (a square wave makes it almost silent), so the output is simply '1' while sounding.
-- A new request restarts the sound; beep_err has priority, then beep_long.
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;

entity io_buzzer is
    generic (
        CLK_HZ : integer := 50_000_000
    );
    port (
        clk        : in  std_logic;
        rst        : in  std_logic;
        beep_short : in  std_logic;
        beep_long  : in  std_logic;
        beep_err   : in  std_logic;
        buzz       : out std_logic
    );
end entity;

architecture rtl of io_buzzer is
    constant SHORT : integer := CLK_HZ / 5;           -- 200 ms
    constant LONG  : integer := CLK_HZ / 2;           -- 500 ms
    constant PART  : integer := CLK_HZ / 10;          -- 100 ms, one third of the error sound
    constant ERR   : integer := 3 * PART;             -- 300 ms: on - off - on

    signal dur    : integer range 0 to LONG := 0;     -- time remaining
    signal is_err : std_logic := '0';
    signal buzz_r : std_logic := '0';
begin
    buzz <= buzz_r;

    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                dur <= 0; is_err <= '0'; buzz_r <= '0';
            else
                if beep_err = '1' then
                    dur <= ERR;  is_err <= '1';
                elsif beep_long = '1' then
                    dur <= LONG; is_err <= '0';
                elsif beep_short = '1' then
                    dur <= SHORT; is_err <= '0';
                elsif dur /= 0 then
                    dur <= dur - 1;
                end if;

                -- sound while dur /= 0, except the middle 100 ms of the error sound
                if dur = 0 then
                    buzz_r <= '0';
                elsif is_err = '1' and dur <= 2 * PART and dur > PART then
                    buzz_r <= '0';
                else
                    buzz_r <= '1';
                end if;
            end if;
        end if;
    end process;
end architecture;
