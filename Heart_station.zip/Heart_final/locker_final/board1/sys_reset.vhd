-- ============================================================
-- sys_reset.vhd  Board reset (used on both boards)
--
--   rst = power-on reset  OR  center button  OR  watchdog
--
--   * power-on reset : 2^20 clocks (~21 ms at 50 MHz) after the FPGA starts
--   * center button  : 2-stage synchronizer (the button is not in the clock domain)
--   * sys_watchdog   : no kick for WDT_S seconds -> reset pulse (WDT_S = 0 -> off)
--
--   por : power-on reset only (the watchdog itself uses it, never its own reset)
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity sys_reset is
    generic (
        CLK_HZ : integer := 50_000_000;
        WDT_S  : integer := 0                 -- watchdog timeout in seconds, 0 = off
    );
    port (
        clk  : in  std_logic;
        btn  : in  std_logic;                 -- center button (pressed = '1')
        kick : in  std_logic;                 -- activity pulse for the watchdog
        rst  : out std_logic;
        por  : out std_logic
    );
end entity;

architecture rtl of sys_reset is
    signal por_cnt  : unsigned(19 downto 0) := (others => '0');
    signal por_r    : std_logic := '1';
    signal rb1, rb2 : std_logic := '0';
    signal wdt_rst  : std_logic;
begin
    process (clk)
    begin
        if rising_edge(clk) then
            rb1 <= btn;                        -- synchronizer
            rb2 <= rb1;
            if por_cnt /= x"FFFFF" then
                por_cnt <= por_cnt + 1;
                por_r   <= '1';
            else
                por_r <= '0';
            end if;
        end if;
    end process;

    u_wdt : entity work.sys_watchdog
        generic map (CLK_HZ => CLK_HZ, TIMEOUT_S => WDT_S)
        port map (clk => clk, por => por_r, kick => kick, wdt_rst => wdt_rst);

    rst <= por_r or rb2 or wdt_rst;
    por <= por_r;
end architecture;
