-- ============================================================
-- bus_uart_tx.vhd  UART transmitter, 8N1 (used on both boards)
--
-- Frame on the line (idle = '1'):
--
--   tx  ‾‾‾‾\_____/ d0 / d1 / d2 / d3 / d4 / d5 / d6 / d7 /‾‾‾‾‾‾‾
--            start   <-------- 8 data bits, LSB first -------> stop
--
--   one bit = CLK_HZ / BAUD clocks  (50 MHz / 115200 = 434 clocks, 8.68 us)
--   one byte = 10 bits = 86.8 us
--
-- send : 1-clock pulse with data -> the byte is sent if the transmitter is idle
--        (a pulse while busy = '1' is ignored)
-- done : 1-clock pulse when the stop bit is finished
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity bus_uart_tx is
    generic (
        CLK_HZ : integer := 50_000_000;
        BAUD   : integer := 115_200
    );
    port (
        clk  : in  std_logic;
        rst  : in  std_logic;
        send : in  std_logic;
        data : in  std_logic_vector(7 downto 0);
        tx   : out std_logic;
        busy : out std_logic;
        done : out std_logic
    );
end entity;

architecture rtl of bus_uart_tx is
    constant BIT_T : integer := CLK_HZ / BAUD;

    signal shreg  : std_logic_vector(9 downto 0) := (others => '1');  -- stop & data & start
    signal nbits  : integer range 0 to 10 := 0;                       -- bits still to send
    signal tmr    : integer range 0 to BIT_T - 1 := 0;
    signal tx_r   : std_logic := '1';
    signal done_r : std_logic := '0';
begin
    tx   <= tx_r;
    busy <= '1' when nbits /= 0 else '0';
    done <= done_r;

    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                shreg  <= (others => '1');
                nbits  <= 0;
                tmr    <= 0;
                tx_r   <= '1';
                done_r <= '0';
            else
                done_r <= '0';
                if nbits = 0 then
                    tx_r <= '1';                               -- idle line
                    if send = '1' then
                        shreg <= '1' & data & '0';             -- stop, data, start
                        nbits <= 10;
                        tmr   <= 0;
                        tx_r  <= '0';                          -- start bit goes out now
                    end if;
                elsif tmr = BIT_T - 1 then                     -- end of one bit
                    tmr <= 0;
                    if nbits = 1 then
                        nbits  <= 0;
                        done_r <= '1';
                        tx_r   <= '1';
                    else
                        nbits <= nbits - 1;
                        shreg <= '1' & shreg(9 downto 1);      -- next bit to position 0
                        tx_r  <= shreg(1);
                    end if;
                else
                    tmr <= tmr + 1;
                end if;
            end if;
        end if;
    end process;
end architecture;
