-- ============================================================
-- bus_link_b1.vhd  (board 1)  Command source + UART link to board 2
--
--   gesture / buttons --> command select --> bus_uart_tx --> uart_tx (to board 2)
--   uart_rx (from board 2) --> bus_uart_rx --> 'A' / 'R' / 'H' decode
--                                          --> reply timeout, link status
--
-- Command select : a gesture has priority, then the buttons
--   right = NEXT, left = PREV, top = CONFIRM, bottom = CANCEL
-- Each command is sent as one byte ('N' 'P' 'C' 'X', see pkg_locker).
--
-- Outputs (all 1-clock pulses except link_ok / sent_cmd):
--   sent      a command byte was handed to the transmitter, sent_cmd = which one
--   got_ack   board 2 answered 'A' (command accepted)
--   got_rej   board 2 answered 'R' (command had no effect)
--   no_reply  no answer within REPLY_MS after a command
--   link_ok   '1' while board 2 was heard (any byte) within the last LINK_S seconds
--             (board 2 sends a heartbeat 'H' every second)
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity bus_link_b1 is
    generic (
        CLK_HZ   : integer := 50_000_000;
        BAUD     : integer := 115_200;
        REPLY_MS : integer := 100;
        LINK_S   : integer := 3
    );
    port (
        clk        : in  std_logic;
        rst        : in  std_logic;
        -- command sources
        gest_valid : in  std_logic;
        gest_cmd   : in  std_logic_vector(2 downto 0);
        btn_rise   : in  std_logic_vector(3 downto 0);
        -- UART pins
        uart_tx    : out std_logic;
        uart_rx    : in  std_logic;
        -- events / status
        sent       : out std_logic;
        sent_cmd   : out std_logic_vector(2 downto 0);
        got_ack    : out std_logic;
        got_rej    : out std_logic;
        no_reply   : out std_logic;
        link_ok    : out std_logic
    );
end entity;

architecture rtl of bus_link_b1 is
    constant MS : integer := CLK_HZ / 1000;

    signal send     : std_logic;
    signal cmd      : std_logic_vector(2 downto 0);
    signal tx_go    : std_logic;
    signal tx_byte  : std_logic_vector(7 downto 0);
    signal tx_busy, tx_done : std_logic;

    signal rx_data  : std_logic_vector(7 downto 0);
    signal rx_valid, rx_ferr : std_logic;
    signal ack_i, rej_i, norep_i : std_logic;

    signal ms_cnt   : integer range 0 to MS - 1 := 0;
    signal ms_tick  : std_logic;
    signal waiting  : std_logic := '0';
    signal wait_ms  : integer range 0 to REPLY_MS := 0;
    signal link_ms  : integer range 0 to LINK_S * 1000 := LINK_S * 1000;
begin
    -- ---------- Command select: gesture first, then buttons ----------
    process (gest_valid, gest_cmd, btn_rise)
    begin
        send <= '1';
        if    gest_valid  = '1' then cmd <= gest_cmd;
        elsif btn_rise(3) = '1' then cmd <= CMD_NEXT;
        elsif btn_rise(2) = '1' then cmd <= CMD_PREV;
        elsif btn_rise(0) = '1' then cmd <= CMD_CONFIRM;
        elsif btn_rise(1) = '1' then cmd <= CMD_CANCEL;
        else  cmd <= CMD_NONE; send <= '0';
        end if;
    end process;

    -- ---------- UART transmitter: one byte per command ----------
    tx_go   <= send and not tx_busy;
    tx_byte <= cmd2byte(cmd);

    u_tx : entity work.bus_uart_tx
        generic map (CLK_HZ => CLK_HZ, BAUD => BAUD)
        port map (clk => clk, rst => rst, send => tx_go, data => tx_byte,
                  tx => uart_tx, busy => tx_busy, done => tx_done);

    sent     <= tx_go;
    sent_cmd <= cmd;

    -- ---------- UART receiver: replies + heartbeat ----------
    u_rx : entity work.bus_uart_rx
        generic map (CLK_HZ => CLK_HZ, BAUD => BAUD)
        port map (clk => clk, rst => rst, rx => uart_rx,
                  data => rx_data, valid => rx_valid, ferr => rx_ferr);

    ack_i <= '1' when rx_valid = '1' and rx_data = U_ACK    else '0';
    rej_i <= '1' when rx_valid = '1' and rx_data = U_REJECT else '0';

    -- ---------- 1 ms tick ----------
    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' or ms_cnt = MS - 1 then ms_cnt <= 0;
            else                                 ms_cnt <= ms_cnt + 1; end if;
        end if;
    end process;
    ms_tick <= '1' when ms_cnt = MS - 1 else '0';

    -- ---------- Reply timeout + link status ----------
    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                waiting <= '0';
                wait_ms <= 0;
                link_ms <= LINK_S * 1000;            -- link down until board 2 is heard
            else
                if tx_go = '1' then
                    waiting <= '1';
                    wait_ms <= 0;
                elsif ack_i = '1' or rej_i = '1' or norep_i = '1' then
                    waiting <= '0';
                elsif waiting = '1' and ms_tick = '1' then
                    wait_ms <= wait_ms + 1;
                end if;

                if rx_valid = '1' then
                    link_ms <= 0;
                elsif ms_tick = '1' and link_ms < LINK_S * 1000 then
                    link_ms <= link_ms + 1;
                end if;
            end if;
        end if;
    end process;
    norep_i <= '1' when waiting = '1' and wait_ms = REPLY_MS else '0';

    got_ack  <= ack_i;
    got_rej  <= rej_i;
    no_reply <= norep_i;
    link_ok  <= '1' when link_ms < LINK_S * 1000 else '0';
end architecture;
