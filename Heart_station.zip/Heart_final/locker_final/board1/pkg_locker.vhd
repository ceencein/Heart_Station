-- ============================================================
-- pkg_locker.vhd  (shared by board 1 and board 2) - 3-slot locker version
--
-- Constants both boards must agree on, plus helper functions
--   * Command codes (3 bits) used inside the boards
--   * UART bytes sent between the boards and their converters
--   * FSM state codes, 7-segment symbol codes
--   * Function that converts a string into bits for the LCD
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

package pkg_locker is

    -- ---------- Command codes (3 bits, used inside each board) ----------
    constant CMD_NONE    : std_logic_vector(2 downto 0) := "000";
    constant CMD_NEXT    : std_logic_vector(2 downto 0) := "001";
    constant CMD_PREV    : std_logic_vector(2 downto 0) := "010";
    constant CMD_CONFIRM : std_logic_vector(2 downto 0) := "011";
    constant CMD_CANCEL  : std_logic_vector(2 downto 0) := "100";

    -- ---------- UART bytes between the boards (115200 baud, 8N1) ----------
    -- board 1 -> board 2 : one byte per command (readable letters, easy to see in a PC terminal)
    constant U_NEXT    : std_logic_vector(7 downto 0) := x"4E";   -- 'N'
    constant U_PREV    : std_logic_vector(7 downto 0) := x"50";   -- 'P'
    constant U_CONFIRM : std_logic_vector(7 downto 0) := x"43";   -- 'C'
    constant U_CANCEL  : std_logic_vector(7 downto 0) := x"58";   -- 'X'
    -- board 2 -> board 1 : reply to each command + heartbeat
    constant U_ACK     : std_logic_vector(7 downto 0) := x"41";   -- 'A' command accepted
    constant U_REJECT  : std_logic_vector(7 downto 0) := x"52";   -- 'R' command had no effect
    constant U_HEART   : std_logic_vector(7 downto 0) := x"48";   -- 'H' board 2 alive (every second)

    -- ---------- Main FSM states (board 2), 5 states ----------
    constant ST_IDLE    : unsigned(2 downto 0) := "000";  -- "Drop and Pick !", all slots locked
    constant ST_ROLE    : unsigned(2 downto 0) := "001";  -- choose giver / receiver
    constant ST_ITEM    : unsigned(2 downto 0) := "010";  -- choose slot 1-3
    constant ST_PROCESS : unsigned(2 downto 0) := "011";  -- chosen slot unlocked, user puts / takes item
    constant ST_DONE    : unsigned(2 downto 0) := "100";  -- relocked, thank-you message, then IDLE

    -- Role
    constant ROLE_GIVER    : std_logic := '0';
    constant ROLE_RECEIVER : std_logic := '1';

    -- ---------- 7-segment symbols (0-9 = digits) ----------
    constant SYM_DASH  : unsigned(3 downto 0) := x"A";   -- '-'
    constant SYM_G     : unsigned(3 downto 0) := x"B";   -- 'G' = giver
    constant SYM_R     : unsigned(3 downto 0) := x"C";   -- 'r' = receiver
    constant SYM_E     : unsigned(3 downto 0) := x"D";   -- 'E'
    constant SYM_BLANK : unsigned(3 downto 0) := x"F";   -- blank

    -- One LCD line = 16 characters x 8 bits
    subtype lcd_line_t is std_logic_vector(127 downto 0);

    -- Convert a string to ASCII bits (first character in the top bits)
    function str2slv(s : string) return std_logic_vector;
    -- Convert a digit 0-9 to its 8-bit ASCII code
    function asc(d : unsigned(3 downto 0)) return std_logic_vector;
    -- Command code <-> UART byte (unknown byte -> CMD_NONE)
    function cmd2byte(c : std_logic_vector(2 downto 0)) return std_logic_vector;
    function byte2cmd(b : std_logic_vector(7 downto 0)) return std_logic_vector;

end package pkg_locker;

package body pkg_locker is

    function str2slv(s : string) return std_logic_vector is
        variable r : std_logic_vector(8 * s'length - 1 downto 0);
        variable k : integer := s'length - 1;
    begin
        for i in s'range loop
            r(8 * k + 7 downto 8 * k) :=
                std_logic_vector(to_unsigned(character'pos(s(i)), 8));
            k := k - 1;
        end loop;
        return r;
    end function;

    function asc(d : unsigned(3 downto 0)) return std_logic_vector is
    begin
        return std_logic_vector(to_unsigned(16#30#, 8) + resize(d, 8));
    end function;

    function cmd2byte(c : std_logic_vector(2 downto 0)) return std_logic_vector is
    begin
        case c is
            when CMD_NEXT    => return U_NEXT;
            when CMD_PREV    => return U_PREV;
            when CMD_CONFIRM => return U_CONFIRM;
            when CMD_CANCEL  => return U_CANCEL;
            when others      => return x"00";
        end case;
    end function;

    function byte2cmd(b : std_logic_vector(7 downto 0)) return std_logic_vector is
    begin
        case b is
            when U_NEXT    => return CMD_NEXT;
            when U_PREV    => return CMD_PREV;
            when U_CONFIRM => return CMD_CONFIRM;
            when U_CANCEL  => return CMD_CANCEL;
            when others    => return CMD_NONE;
        end case;
    end function;

end package body pkg_locker;
