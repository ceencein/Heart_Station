-- ============================================================
-- sensor_i2c.vhd  (board 1)  I2C master for the PAJ7620
--
-- 100 kHz I2C master, 3 modes
--   "00" write 1 byte      : START | ADDR+W | wdata | STOP          (LCD PCF8574)
--   "01" write register    : START | ADDR+W | reg | wdata | STOP    (PAJ7620)
--   "10" read register     : START | ADDR+W | reg | STOP |
--                            START | ADDR+R | rdata(NACK) | STOP    (PAJ7620)
--
-- To start : set mode/dev_addr/reg_addr/wdata, then pulse start = '1' for one clock
-- When done: done = '1' for one clock, ack_err = '1' if the slave did not ACK
--
-- Method : each I2C bit is split into 4 quarters so SDA changes
--          while SCL is low and is sampled in the middle of SCL high
--
-- SCL/SDA are open-drain: scl_o/sda_o = '1' means "release" (pull-up pulls high)
-- In the top level use :  SDA <= 'Z' when sda_o = '1' else '0';
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity sensor_i2c is
    generic (
        CLK_HZ : integer := 50_000_000;
        I2C_HZ : integer := 100_000
    );
    port (
        clk      : in  std_logic;
        rst      : in  std_logic;
        start    : in  std_logic;
        mode     : in  std_logic_vector(1 downto 0);
        dev_addr : in  std_logic_vector(6 downto 0);
        reg_addr : in  std_logic_vector(7 downto 0);
        wdata    : in  std_logic_vector(7 downto 0);
        rdata    : out std_logic_vector(7 downto 0);
        busy     : out std_logic;
        done     : out std_logic;
        ack_err  : out std_logic;
        scl_o    : out std_logic;
        sda_o    : out std_logic;
        sda_i    : in  std_logic
    );
end entity;

architecture rtl of sensor_i2c is

    constant QDIV : integer := CLK_HZ / (I2C_HZ * 4);   -- 50 MHz / 400 kHz = 125

    type op_t is (OP_START, OP_STOP, OP_TX, OP_RX, OP_END);

    -- Sequence of steps for each mode
    function seq_op(m : std_logic_vector(1 downto 0); s : integer) return op_t is
    begin
        if m = "00" then
            case s is
                when 0      => return OP_START;
                when 1 | 2  => return OP_TX;
                when 3      => return OP_STOP;
                when others => return OP_END;
            end case;
        elsif m = "01" then
            case s is
                when 0         => return OP_START;
                when 1 | 2 | 3 => return OP_TX;
                when 4         => return OP_STOP;
                when others    => return OP_END;
            end case;
        else
            case s is
                when 0      => return OP_START;
                when 1 | 2  => return OP_TX;
                when 3      => return OP_STOP;
                when 4      => return OP_START;
                when 5      => return OP_TX;
                when 6      => return OP_RX;
                when 7      => return OP_STOP;
                when others => return OP_END;
            end case;
        end if;
    end function;

    -- Byte to send at a given step
    function seq_byte(m : std_logic_vector(1 downto 0); s : integer;
                      d : std_logic_vector(6 downto 0);
                      r, w : std_logic_vector(7 downto 0)) return std_logic_vector is
    begin
        if s = 1 then
            return d & '0';                 -- address + Write
        elsif m = "00" then
            return w;
        elsif s = 2 then
            return r;                       -- register number
        elsif m = "01" then
            return w;
        else
            return d & '1';                 -- address + Read (step 5 of read mode)
        end if;
    end function;

    signal mode_r  : std_logic_vector(1 downto 0) := "00";
    signal dev_r   : std_logic_vector(6 downto 0) := (others => '0');
    signal reg_r   : std_logic_vector(7 downto 0) := (others => '0');
    signal wdata_r : std_logic_vector(7 downto 0) := (others => '0');

    signal qcnt  : integer range 0 to QDIV := 0;
    signal q     : unsigned(1 downto 0) := "00";   -- quarter of the bit 0..3
    signal step  : integer range 0 to 15 := 0;     -- step within the transaction
    signal bitn  : integer range 0 to 8 := 0;      -- 0..7 = data, 8 = ACK
    signal shreg : std_logic_vector(7 downto 0) := (others => '0');

    signal busy_r, done_r, ackerr_r : std_logic := '0';
    signal scl_r, sda_r             : std_logic := '1';
    signal rdata_r                  : std_logic_vector(7 downto 0) := (others => '0');

    signal sda_s1, sda_s2 : std_logic := '1';      -- synchronizer for incoming SDA

begin

    rdata   <= rdata_r;
    busy    <= busy_r;
    done    <= done_r;
    ack_err <= ackerr_r;
    scl_o   <= scl_r;
    sda_o   <= sda_r;

    process (clk)
        variable nxt : integer range 0 to 15;
    begin
        if rising_edge(clk) then
            -- Force to plain '0'/'1' ('H' from the pull-up in simulation becomes '1')
            if sda_i = '0' then sda_s1 <= '0'; else sda_s1 <= '1'; end if;
            sda_s2 <= sda_s1;

            if rst = '1' then
                busy_r   <= '0';
                done_r   <= '0';
                ackerr_r <= '0';
                scl_r    <= '1';
                sda_r    <= '1';
                qcnt     <= 0;
                q        <= "00";
                step     <= 0;
                bitn     <= 0;
                shreg    <= (others => '0');
                rdata_r  <= (others => '0');
                mode_r   <= "00";
                dev_r    <= (others => '0');
                reg_r    <= (others => '0');
                wdata_r  <= (others => '0');
            else
                done_r <= '0';
                if step < 15 then nxt := step + 1; else nxt := 15; end if;

                if busy_r = '0' then
                    -- ---------- Idle: wait for a command ----------
                    qcnt  <= 0;
                    scl_r <= '1';
                    sda_r <= '1';
                    if start = '1' then
                        busy_r   <= '1';
                        ackerr_r <= '0';
                        mode_r   <= mode;
                        dev_r    <= dev_addr;
                        reg_r    <= reg_addr;
                        wdata_r  <= wdata;
                        step     <= 0;
                        q        <= "00";
                        bitn     <= 0;
                    end if;

                elsif qcnt /= QDIV - 1 then
                    qcnt <= qcnt + 1;

                else
                    qcnt <= 0;
                    q    <= q + 1;

                    case seq_op(mode_r, step) is
                        -- ---------------- START : SDA falls while SCL high ----------------
                        when OP_START =>
                            case q is
                                when "00" | "01" => scl_r <= '1'; sda_r <= '1';
                                when "10"        => scl_r <= '1'; sda_r <= '0';
                                when others =>
                                    scl_r <= '0'; sda_r <= '0';
                                    step  <= nxt;
                                    bitn  <= 0;
                                    shreg <= seq_byte(mode_r, nxt, dev_r, reg_r, wdata_r);
                            end case;

                        -- ---------------- STOP : SDA rises while SCL high ----------------
                        when OP_STOP =>
                            case q is
                                when "00" => scl_r <= '0'; sda_r <= '0';
                                when "01" => scl_r <= '1'; sda_r <= '0';
                                when "10" => scl_r <= '1'; sda_r <= '1';
                                when others =>
                                    scl_r <= '1'; sda_r <= '1';
                                    step  <= nxt;
                                    bitn  <= 0;
                                    shreg <= seq_byte(mode_r, nxt, dev_r, reg_r, wdata_r);
                                    if seq_op(mode_r, nxt) = OP_END then
                                        busy_r <= '0';
                                        done_r <= '1';
                                    end if;
                            end case;

                        -- ---------------- Send 8 bits + read ACK ----------------
                        when OP_TX =>
                            case q is
                                when "00" =>
                                    scl_r <= '0';
                                    if bitn < 8 then sda_r <= shreg(7);
                                    else             sda_r <= '1';      -- release so the slave can ACK
                                    end if;
                                when "01" =>
                                    scl_r <= '1';
                                when "10" =>
                                    if bitn = 8 and sda_s2 = '1' then
                                        ackerr_r <= '1';                -- no ACK
                                    end if;
                                when others =>
                                    scl_r <= '0';
                                    if bitn = 8 then
                                        step  <= nxt;
                                        bitn  <= 0;
                                        shreg <= seq_byte(mode_r, nxt, dev_r, reg_r, wdata_r);
                                    else
                                        shreg <= shreg(6 downto 0) & '0';
                                        bitn  <= bitn + 1;
                                    end if;
                            end case;

                        -- ---------------- Receive 8 bits then send NACK ----------------
                        when OP_RX =>
                            case q is
                                when "00" =>
                                    scl_r <= '0'; sda_r <= '1';
                                when "01" =>
                                    scl_r <= '1';
                                when "10" =>
                                    if bitn < 8 then
                                        shreg <= shreg(6 downto 0) & sda_s2;
                                    end if;
                                when others =>
                                    scl_r <= '0';
                                    if bitn = 8 then
                                        rdata_r <= shreg;
                                        step    <= nxt;
                                        bitn    <= 0;
                                    else
                                        bitn <= bitn + 1;
                                    end if;
                            end case;

                        when OP_END =>
                            busy_r <= '0';
                            done_r <= '1';
                    end case;
                end if;
            end if;
        end if;
    end process;

end architecture;
