-- ============================================================
-- bus_uart_rx.vhd  UART receiver, 8N1 (used on both boards)
--
--   1) 2-stage synchronizer: the other board has its own clock (asynchronous)
--   2) wait for the line to go '0' (start bit), wait half a bit, check it is
--      still '0' -> a short noise spike is not taken as a start bit
--   3) sample the 8 data bits in the middle of each bit (LSB first)
--   4) the stop bit must be '1', otherwise the byte is thrown away (ferr pulse)
--
--   valid : 1-clock pulse, data holds the received byte
--   ferr  : 1-clock pulse when a frame had a bad stop bit (noise / wrong baud)
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity bus_uart_rx is
    generic (
        CLK_HZ : integer := 50_000_000;
        BAUD   : integer := 115_200
    );
    port (
        clk   : in  std_logic;
        rst   : in  std_logic;
        rx    : in  std_logic;
        data  : out std_logic_vector(7 downto 0);
        valid : out std_logic;
        ferr  : out std_logic
    );
end entity;

architecture rtl of bus_uart_rx is
    constant BIT_T  : integer := CLK_HZ / BAUD;
    constant HALF_T : integer := BIT_T / 2;

    type state_t is (S_IDLE, S_START, S_DATA, S_STOP);
    signal st     : state_t := S_IDLE;
    -- if a glitch ever puts st in an unused code, Vivado returns it to the reset state
    attribute fsm_safe_state : string;
    attribute fsm_safe_state of st : signal is "reset_state";

    signal s1, s2  : std_logic := '1';                -- synchronizer
    signal tmr     : integer range 0 to BIT_T - 1 := 0;
    signal nbit    : integer range 0 to 7 := 0;
    signal shreg   : std_logic_vector(7 downto 0) := (others => '0');
    signal data_r  : std_logic_vector(7 downto 0) := (others => '0');
    signal valid_r : std_logic := '0';
    signal ferr_r  : std_logic := '0';
begin
    data  <= data_r;
    valid <= valid_r;
    ferr  <= ferr_r;

    process (clk)
    begin
        if rising_edge(clk) then
            -- synchronizer ('H' from a pull-up in simulation reads as '1')
            if rx = '0' then s1 <= '0'; else s1 <= '1'; end if;
            s2 <= s1;

            if rst = '1' then
                st      <= S_IDLE;
                tmr     <= 0;
                nbit    <= 0;
                valid_r <= '0';
                ferr_r  <= '0';
            else
                valid_r <= '0';
                ferr_r  <= '0';
                case st is
                    when S_IDLE =>
                        tmr <= 0;
                        if s2 = '0' then st <= S_START; end if;

                    when S_START =>                            -- middle of the start bit
                        if tmr = HALF_T - 1 then
                            tmr <= 0;
                            if s2 = '0' then
                                nbit <= 0;
                                st   <= S_DATA;
                            else
                                st <= S_IDLE;                  -- just a spike
                            end if;
                        else
                            tmr <= tmr + 1;
                        end if;

                    when S_DATA =>                             -- middle of each data bit
                        if tmr = BIT_T - 1 then
                            tmr   <= 0;
                            shreg <= s2 & shreg(7 downto 1);   -- LSB first
                            if nbit = 7 then st <= S_STOP;
                            else             nbit <= nbit + 1; end if;
                        else
                            tmr <= tmr + 1;
                        end if;

                    when S_STOP =>                             -- middle of the stop bit
                        if tmr = BIT_T - 1 then
                            tmr <= 0;
                            if s2 = '1' then
                                data_r  <= shreg;
                                valid_r <= '1';
                            else
                                ferr_r <= '1';                 -- bad frame: drop it
                            end if;
                            st <= S_IDLE;
                        else
                            tmr <= tmr + 1;
                        end if;
                end case;
            end if;
        end if;
    end process;
end architecture;
