-- ============================================================
-- io_status.vhd  (board 1)  What the user sees / hears on board 1
--
--   events from bus_link_b1 --> last command + count + result --> LEDs
--                                                              --> io_seg7   (7-segment)
--                                                              --> io_buzzer (sound)
--
-- LEDs : led(0) NEXT  led(1) PREV  led(2) CONFIRM  led(3) CANCEL  (last command sent)
--        led(4) sensor ready   led(5) sensor error
--        led(6) link OK        led(7) last command rejected / no answer
-- 7-segment : [cmd 1-4] [status] [count 00-99]
--   status '-' = accepted,  'r' = rejected / no answer,  'E' = link down
-- Sound : 'A' -> one beep (long for CONFIRM, short for the others)
--         'R' or no answer -> two short beeps
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.pkg_locker.all;

entity io_status is
    generic (
        CLK_HZ         : integer := 50_000_000;
        LEFT_IS_DIGIT0 : boolean := true
    );
    port (
        clk           : in  std_logic;
        rst           : in  std_logic;
        sent          : in  std_logic;
        sent_cmd      : in  std_logic_vector(2 downto 0);
        got_ack       : in  std_logic;
        got_rej       : in  std_logic;
        no_reply      : in  std_logic;
        link_ok       : in  std_logic;
        init_done     : in  std_logic;
        sensor_err    : in  std_logic;
        led           : out std_logic_vector(7 downto 0);
        digit         : out std_logic_vector(3 downto 0);
        Seven_Segment : out std_logic_vector(7 downto 0);
        Buzzer        : out std_logic
    );
end entity;

architecture rtl of io_status is
    signal last_cmd : std_logic_vector(2 downto 0) := CMD_NONE;
    signal cnt_ten, cnt_one : unsigned(3 downto 0) := (others => '0');
    signal bad_r    : std_logic := '0';
    signal sym3, sym2 : unsigned(3 downto 0);
    signal beep_short, beep_long, beep_err : std_logic;
begin
    -- ---------- Last command, BCD count 00-99, last result ----------
    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                last_cmd <= CMD_NONE;
                cnt_ten  <= (others => '0');
                cnt_one  <= (others => '0');
                bad_r    <= '0';
            else
                if sent = '1' then
                    last_cmd <= sent_cmd;
                    if cnt_one = 9 then
                        cnt_one <= (others => '0');
                        if cnt_ten = 9 then cnt_ten <= (others => '0');
                        else                cnt_ten <= cnt_ten + 1; end if;
                    else
                        cnt_one <= cnt_one + 1;
                    end if;
                end if;
                if got_ack = '1' then
                    bad_r <= '0';
                elsif got_rej = '1' or no_reply = '1' then
                    bad_r <= '1';
                end if;
            end if;
        end if;
    end process;

    -- ---------- LEDs ----------
    led(0) <= '1' when last_cmd = CMD_NEXT    else '0';
    led(1) <= '1' when last_cmd = CMD_PREV    else '0';
    led(2) <= '1' when last_cmd = CMD_CONFIRM else '0';
    led(3) <= '1' when last_cmd = CMD_CANCEL  else '0';
    led(4) <= init_done;
    led(5) <= sensor_err;
    led(6) <= link_ok;
    led(7) <= bad_r;

    -- ---------- 7-segment ----------
    sym3 <= SYM_DASH when last_cmd = CMD_NONE else resize(unsigned(last_cmd), 4);
    sym2 <= SYM_E    when link_ok = '0' else
            SYM_R    when bad_r   = '1' else
            SYM_DASH;

    u_seg : entity work.io_seg7
        generic map (LEFT_IS_DIGIT0 => LEFT_IS_DIGIT0)
        port map (clk => clk, rst => rst,
                  sym3 => sym3, sym2 => sym2, sym1 => cnt_ten, sym0 => cnt_one,
                  digit => digit, Seven_Segment => Seven_Segment);

    -- ---------- Buzzer: sound only after board 2 answered ----------
    beep_long  <= '1' when got_ack = '1' and last_cmd =  CMD_CONFIRM else '0';
    beep_short <= '1' when got_ack = '1' and last_cmd /= CMD_CONFIRM else '0';
    beep_err   <= got_rej or no_reply;

    u_bz : entity work.io_buzzer
        generic map (CLK_HZ => CLK_HZ)
        port map (clk => clk, rst => rst,
                  beep_short => beep_short, beep_long => beep_long, beep_err => beep_err,
                  buzz => Buzzer);
end architecture;
