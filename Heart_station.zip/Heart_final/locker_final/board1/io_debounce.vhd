-- ============================================================
-- io_debounce.vhd  (shared by board 1 and board 2)
--
-- 1) 2-stage synchronizer : prevents metastability from external inputs (buttons)
-- 2) Debounce             : value must stay stable for STABLE_CYC clocks to be accepted
-- 3) Edge detect          : 1-clock pulse when the value changes
--
--   level : filtered value
--   rise  : 1-clock pulse when level goes 0 -> 1
--   fall  : 1-clock pulse when level goes 1 -> 0
--
-- STABLE_CYC at 50 MHz : 1 ms = 50_000, 10 ms = 500_000
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;

entity io_debounce is
    generic (
        STABLE_CYC : integer := 500_000
    );
    port (
        clk   : in  std_logic;
        rst   : in  std_logic;
        din   : in  std_logic;
        level : out std_logic;
        rise  : out std_logic;
        fall  : out std_logic
    );
end entity;

architecture rtl of io_debounce is
    signal s1, s2  : std_logic := '0';
    signal lvl     : std_logic := '0';
    signal cnt     : integer range 0 to STABLE_CYC := 0;
begin
    level <= lvl;

    process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                s1   <= '0';
                s2   <= '0';
                cnt  <= 0;
                lvl  <= '0';
                rise <= '0';
                fall <= '0';
            else
                s1   <= din;
                s2   <= s1;
                rise <= '0';
                fall <= '0';

                if s2 = lvl then
                    cnt <= 0;                       -- unchanged, restart count
                elsif cnt >= STABLE_CYC - 1 then
                    cnt <= 0;
                    lvl <= s2;                      -- stable long enough, accept new value
                    if s2 = '1' then rise <= '1';
                    else             fall <= '1';
                    end if;
                else
                    cnt <= cnt + 1;
                end if;
            end if;
        end if;
    end process;
end architecture;
