-- ============================================================
-- board1.vhd  TOP OF BOARD 1 : touchless input (gesture sensor -> UART -> board 2)
--
-- This top only connects 5 blocks (no logic of its own):
--
--   pb(4) ----------> [sys_reset] ----------------------------------> rst (all blocks)
--                        ^ kick = sent (watchdog)
--   pb(3:0) --------> [io_buttons] --btn_rise--+
--                                              v
--   PAJ7620 <-I2C---> [sensor_paj7620] --gesture--> [bus_link_b1] --uart_tx--> board 2
--                         | ready / error          |      ^------uart_rx--- board 2
--                         v                        v events
--                      [io_status] <---------------+
--                         +--> led(7:0), 7-segment, Buzzer
--
--   sys_reset      : power-on reset + center button + watchdog (sys_watchdog)
--   io_buttons     : 4 x io_debounce
--   sensor_paj7620 : PAJ7620 controller (sensor_i2c + sensor_paj7620_rom inside)
--   bus_link_b1    : command select, UART send / receive (bus_uart_tx, bus_uart_rx),
--                    reply timeout, link status
--   io_status      : LEDs, io_seg7, io_buzzer
--
-- UART link (115200 baud, 8N1): sends 'N' 'P' 'C' 'X', board 2 answers 'A' / 'R',
-- and sends 'H' every second. Wiring: J5 pin4 GND, pin5 TX -> board 2 pin5,
-- pin6 RX <- board 2 pin6.
--
-- LEDs : led(0..3) last command  led(4) sensor ready  led(5) sensor error
--        led(6) link OK  led(7) last command rejected / no answer
-- 7-segment : [cmd 1-4] [status - / r / E] [count 00-99]
-- Buttons : right = NEXT, left = PREV, top = CONFIRM, bottom = CANCEL, center = reset
-- ============================================================
library ieee;
use ieee.std_logic_1164.all;
use work.pkg_locker.all;

entity board1 is
    generic (
        CLK_HZ         : integer := 50_000_000;
        LEFT_IS_DIGIT0 : boolean := true;     -- 7-segment digit order (vendor XDC: digit[0] = left)
        -- ---- gesture -> command (bit numbers of register 0x43) ----
        NEXT_BIT       : integer := 3;        -- swipe right
        PREV_BIT       : integer := 2;        -- swipe left
        CONFIRM_BIT    : integer := 6;        -- clockwise
        CANCEL_BIT     : integer := 7;        -- counter-clockwise
        -- ---- sensor speed / noise filter ----
        POLL_MS        : integer := 10;
        HOLD_MS        : integer := 150;
        REJECT_MULTI   : boolean := true;
        -- ---- watchdog ----
        WDT_S          : integer := 120;      -- quiet seconds before auto reset, 0 = off
        -- ---- UART link ----
        BAUD           : integer := 115_200;
        REPLY_MS       : integer := 100;      -- board 2 must answer a command within this time
        LINK_S         : integer := 3         -- link down if nothing heard from board 2 for this long
    );
    port (
        clk           : in    std_logic;      -- 50 MHz
        pb            : in    std_logic_vector(4 downto 0);
        led           : out   std_logic_vector(7 downto 0);
        digit         : out   std_logic_vector(3 downto 0);
        Seven_Segment : out   std_logic_vector(7 downto 0);
        Buzzer        : out   std_logic;
        paj_scl       : inout std_logic;
        paj_sda       : inout std_logic;
        uart_tx       : out   std_logic;      -- J5 pin5 -> board 2 J5 pin5
        uart_rx       : in    std_logic       -- J5 pin6 <- board 2 J5 pin6
    );
end entity;

architecture rtl of board1 is
    signal rst, por    : std_logic;
    signal btn_rise    : std_logic_vector(3 downto 0);
    -- sensor
    signal gest_valid, raw_valid, init_done, sensor_err : std_logic;
    signal gest_cmd    : std_logic_vector(2 downto 0);
    signal gest_raw    : std_logic_vector(7 downto 0);
    signal scl_o, sda_o : std_logic;
    -- link events
    signal sent, got_ack, got_rej, no_reply, link_ok : std_logic;
    signal sent_cmd    : std_logic_vector(2 downto 0);
begin
    u_rst : entity work.sys_reset
        generic map (CLK_HZ => CLK_HZ, WDT_S => WDT_S)
        port map (clk => clk, btn => pb(4), kick => sent, rst => rst, por => por);

    u_btn : entity work.io_buttons
        generic map (CLK_HZ => CLK_HZ)
        port map (clk => clk, rst => rst, pb => pb(3 downto 0), rise => btn_rise);

    u_paj : entity work.sensor_paj7620
        generic map (CLK_HZ => CLK_HZ, POLL_MS => POLL_MS, HOLD_MS => HOLD_MS,
                     REJECT_MULTI => REJECT_MULTI,
                     NEXT_BIT => NEXT_BIT, PREV_BIT => PREV_BIT,
                     CONFIRM_BIT => CONFIRM_BIT, CANCEL_BIT => CANCEL_BIT)
        port map (clk => clk, rst => rst,
                  gest_valid => gest_valid, gest_cmd => gest_cmd, gest_raw => gest_raw,
                  raw_valid => raw_valid, init_done => init_done, sensor_err => sensor_err,
                  scl_o => scl_o, sda_o => sda_o, sda_i => paj_sda);

    -- I2C pins are open-drain: drive '0' or release ('Z', the pull-up makes '1')
    paj_scl <= 'Z' when scl_o = '1' else '0';
    paj_sda <= 'Z' when sda_o = '1' else '0';

    u_link : entity work.bus_link_b1
        generic map (CLK_HZ => CLK_HZ, BAUD => BAUD, REPLY_MS => REPLY_MS, LINK_S => LINK_S)
        port map (clk => clk, rst => rst,
                  gest_valid => gest_valid, gest_cmd => gest_cmd, btn_rise => btn_rise,
                  uart_tx => uart_tx, uart_rx => uart_rx,
                  sent => sent, sent_cmd => sent_cmd, got_ack => got_ack, got_rej => got_rej,
                  no_reply => no_reply, link_ok => link_ok);

    u_stat : entity work.io_status
        generic map (CLK_HZ => CLK_HZ, LEFT_IS_DIGIT0 => LEFT_IS_DIGIT0)
        port map (clk => clk, rst => rst,
                  sent => sent, sent_cmd => sent_cmd, got_ack => got_ack, got_rej => got_rej,
                  no_reply => no_reply, link_ok => link_ok,
                  init_done => init_done, sensor_err => sensor_err,
                  led => led, digit => digit, Seven_Segment => Seven_Segment, Buzzer => Buzzer);
end architecture;
